using System;
using System.ComponentModel;
using System.Threading.Tasks;
using Alife.Framework;
using Microsoft.Extensions.Logging;

namespace BDFFZI.MaoMao.SelfAwake;

public class AwakeConfig
{
    [Description("活跃间隔秒数")]
    public int IntervalSeconds { get; set; } = 60;
    [Description("是否启用")]
    public bool Enabled { get; set; } = false;
}

[Module("固定周期唤醒",
    "按固定周期主动唤醒角色，不必干等系统报点，可主动看弹幕、陪主人或干活。",
    defaultCategory: "真央的小工具")]
public class SelfAwakeService(
    ILogger<SelfAwakeService> logger,
    Interactor<SelfAwakeService> interactor) :
    ChatBehaviour,
    IConfigurable<AwakeConfig>
{
    public AwakeConfig Configuration { get; set; } = null!;
    DateTime lastTick = DateTime.Now;

    protected override Task OnUpdate()
    {
        if (!Configuration.Enabled) return Task.CompletedTask;
        if ((DateTime.Now - lastTick).TotalSeconds < Configuration.IntervalSeconds) return Task.CompletedTask;
        lastTick = DateTime.Now;
        try { interactor.Poke("[自我唤醒] 活跃时间到，主动看看弹幕、陪陪主人或干点活喵！"); }
        catch (Exception ex) { logger.LogWarning(ex, "自我唤醒交互失败"); }
        return Task.CompletedTask;
    }
}
