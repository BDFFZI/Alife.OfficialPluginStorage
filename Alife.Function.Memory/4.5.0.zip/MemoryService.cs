using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Alife.Foundation;
using Alife.Framework;
using Alife.Function.FunctionCaller;
using Alife.Function.MessageFilter;
using Microsoft.Extensions.Logging;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.Agents;
using Microsoft.SemanticKernel.ChatCompletion;

namespace Alife.Function.Memory;

[Module("持久记忆",
    "自动管理和分层压缩对话记忆，提供长期记忆检索能力。",
    defaultCategory: "Alife 官方/生活环境",
    LaunchOrder = -10000, //期望提前创建，以便在其他功能之前写入记忆上下文 
    EditorUI = typeof(MemoryServiceUI))]
public class MemoryService(
    ModuleSystem moduleSystem,
    Interactor<MemoryService> interactor,
    ILogger<MemoryService> logger,
    XmlFunctionCaller functionService,
    ILanguageModel languageModel,
    IMessageFilterService messageFilterService) :
    ChatBehaviour,
    IConfigurable<MemoryConfig>
{
    public MemoryConfig Configuration { get; set; } = null!;

    [XmlFunction(FunctionMode.OneShot)]
    public async Task ReadMemoryArchive([Description("存档id")] string id)
    {
        string? memory = await memoryManager.ReadMemory(id);
        interactor.Poke(memory != null
            ? $"读取[记忆存档({id})]内容如下：\n{memory}"
            : $"未找到[记忆存档({id})]");
    }

    [XmlFunction(FunctionMode.OneShot)]
    public async Task SearchMemoryArchive(
        [Description("精准匹配关键词（仅支持一个，不要太具体避免搜不到）")] string? keyword = null,
        [Description("向量搜索提示词（仅用于排序，为空则基于时间排序）")] string? prompt = null,
        [Description("页码，从1开始")] int page = 1,
        [Description("每页条数")] int count = 5,
        [Description("存档层级（推荐3级，信息冗余少，损耗适中）")] int level = 3,
        [Description("ISO-8601格式，不填则不限")] DateTime? startTime = null,
        [Description("ISO-8601格式，不填则不限")] DateTime? endTime = null)
    {
        keyword = keyword?.Trim() ?? "";
        if (keyword.Contains(' '))
            throw new Exception("不支持使用空格拆分多关键词搜索！");
        if (!string.IsNullOrEmpty(prompt) && vectorizer == null)
            throw new Exception("当前未启用向量功能，不支持语义搜索（prompt 参数）！请先在记忆配置中开启 EnableVector，或仅使用关键词搜索。");

        int offset = (page - 1) * count;
        (List<SearchResult> results, int total) = await memoryManager.SearchMemory(level, keyword, prompt, count, offset, startTime, endTime);

        StringBuilder stringBuilder = new();
        if (total == 0)
        {
            stringBuilder.AppendLine(keyword + "在" + level + "级存档中未匹配到内容。");
            interactor.Poke(stringBuilder.ToString());
            return;
        }

        int totalPages = (total + count - 1) / count;
        stringBuilder.AppendLine($"“{keyword}”的搜索结果（第{page}页，共{totalPages}页）：");
        for (int index = 0; index < results.Count; index++)
        {
            SearchResult searchResult = results[index];
            string highlighted = HighlightKeyword(searchResult.Summary, keyword);
            stringBuilder.AppendLine(
                $"""
                 > {index + 1}
                 [记忆存档({searchResult.Name})]
                 {highlighted}
                 """);
        }

        if (page < totalPages)
        {
            int remaining = total - page * count;
            stringBuilder.AppendLine($"\n(还有 {remaining} 条结果，可用 <Search page=\"{page + 1}\"> 继续翻页查看)");
        }

        interactor.Poke(stringBuilder.ToString());

        static string HighlightKeyword(string text, string keyword)
        {
            string[] lines = text.Split('\n');
            var matched = lines.Where(line => line.Contains(keyword, StringComparison.OrdinalIgnoreCase)).ToList();
            return matched.Count > 0 ? string.Join("\n", matched) : $"…（未显示含“{keyword}”的匹配行）…\n{string.Join("\n", lines.Take(3))}";
        }
    }


    [XmlFunction(FunctionMode.Content)]
    [Description("创建一个永久记忆（仅能用于存储珍贵的核心记忆（与他人相关的记忆），不要用来存储个人休闲活动信息）")]
    public async Task Memorize(XmlExecutorContext ctx,
        [Description("格式为ISO-8601")] DateTime? startTime = null,
        [Description("格式为ISO-8601")] DateTime? endTime = null
    )
    {
        if (ctx.CallMode == CallMode.Closing)
        {
            DateTime start = startTime ?? DateTime.Now;
            DateTime end = endTime ?? DateTime.Now;

            string name = await InsertMemory(100, ctx.FullContent.Trim(), "手动存储的记忆，无原始内容。", start, end);
            interactor.Poke($"成功插入永久记忆存档：{name}");
        }
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("移除一个永久记忆")]
    public async void Forget([Description("存档索引")] string index)
    {
        try
        {
            index = index.Trim();
            ChatMessageContent? target = ChatBot.ChatHistory.FirstOrDefault(c => memoryManager.GetMemoryMetaData(c).Name == index);
            if (target == null)
            {
                interactor.Poke($"未能在当前上下文中找到索引为 '{index}' 的记忆记录。");
                return;
            }

            MemoryMeta memoryMeta = memoryManager.GetMemoryMetaData(target);
            if (memoryMeta.Level < Configuration.MaxCompressionLevel)
            {
                interactor.Poke($"仅支持删除层级大于等于 {Configuration.MaxCompressionLevel} 的记忆");
                return;
            }

            await ChatBot.EditChatHistoryAsync(thread => {
                memoryManager.RemoveMemory(thread.ChatHistory, target);
                return Task.CompletedTask;
            }, "删除永久记忆");

            interactor.Poke($"成功移除记忆存档：{index}（不过你仍可以通过 {nameof(ReadMemoryArchive)} 读取其内容）");
        }
        catch (Exception e)
        {
            AlifeLog.LogError(e);
        }
    }

    public async Task<string> InsertMemory(int level, string summary, string content, DateTime startTime, DateTime endTime)
    {
        string? name = null;
        await ChatBot.EditChatHistoryAsync(
            async thread => {
                name = await memoryManager.InsertMemory(thread.ChatHistory, level, summary, content, startTime, endTime);
            }, "插入永久记忆");
        if (name == null)
            throw new Exception("永久记忆插入失败。");

        return name;
    }

    TextVectorizer? vectorizer;
    MemoryManager memoryManager = null!;
    ILanguageModel compressModel = null!;
    string storagePath = null!;
    int compressing; //压缩进行中标志（含LLM归纳阶段），防重入

    protected override Task OnAwake()
    {
        if (messageFilterService.IsEnabledTimestamp == false)
            throw new Exception("持久记忆依赖消息过滤的时间戳功能，请先打开时间戳！");

        storagePath = Path.Combine(AlifePath.StorageFolderPath, Character.StorageKey, "Memory");

        //插入提示词
        XmlHandler xmlHandler = new(this) {
            Description = "当你想要回忆往事或存储额外记忆时使用",
            Explanation = $$"""
                            记忆存储介绍
                            - 早期聊天记录会被总结为记忆存档，每个存档有唯一ID，格式为`等级-最早日期范围-最大日期范围`。其中等级表示被压缩次数（早期存档也会被二次压缩）
                            - 可以通过<{{nameof(ReadMemoryArchive)}}>查看存档压缩的内容。内容中可能是嵌套的存档，因此需要多次调用才能拿到最原始的聊天记录
                            - 存档中被压缩内容不会丢失，而是以存档id为名永久存储在`{{storagePath}}`中，可利用记忆工具或文件工具查看

                            如何恢复记忆
                            1. 预估大致时间范围，或根据概述所在存档，通过<{{nameof(ReadMemoryArchive)}}>查看记忆存档的完整内容
                            2. 根据关键词通过<{{nameof(SearchMemoryArchive)}}>查找疑似存档，然后重复第一步
                            3. 备选方案，通过文件系统直接浏览搜索存档目录中的所有文件
                            """
        };
        functionService.RegisterHandler(xmlHandler, DocumentMode.Implicit, DestroyCancellationToken);

        return Task.CompletedTask;
    }
    protected override async Task OnStart()
    {
        //创建记忆工具（向量默认关闭，避免拉起 Python/torch 模型开销）
        vectorizer = Configuration.EnableVector ? await TextVectorizer.CreateAsync() : null;
        compressModel = await ResolveCompressModel();
        AlifeHistoryCompressor compressor = new(compressModel, Configuration.Probability, Configuration.CompressPrompt);
        memoryManager = new MemoryManager(compressor, vectorizer, storagePath, Configuration.Threshold,
            Configuration.BatchSize,
            Configuration.MaxCompressionLevel);

        //加载历史记忆（Awake中常用于插入提示词，故将记忆对话纪录放到Start中）
        await ChatBot.EditChatHistoryAsync(thread => {
            memoryManager.LoadHistory(thread.ChatHistory);
            return Task.CompletedTask;
        }, "装载记忆");

        ChatBot.ChatSend += OnChatSend;
        ChatBot.ChatHistoryAdd += OnChatHistoryAdd; //每次对话后检测压缩
        ChatBot.TokenUsed += OnTokenUsed; //监控上下文token消耗
    }

    /// <summary>
    /// 解析用于压缩的语言模型：若配置了类名且类型存在，则从容器中获取，否则回退到默认语言模型。
    /// </summary>
    async Task<ILanguageModel> ResolveCompressModel()
    {
        string className = Configuration.CompressModelClassName;
        if (string.IsNullOrWhiteSpace(className))
            return languageModel;

        Type? modelType = moduleSystem.GetAllModules()
            .FirstOrDefault(type => type.Name == className || type.FullName == className);
        if (modelType == null)
        {
            logger.LogWarning("未找到压缩语言模型类型“{ClassName}”，将使用默认语言模型。", className);
            return languageModel;
        }

        try
        {
            object instance = await ChatActivity.Container.RequireInstance(modelType, true);
            if (instance is ILanguageModel model)
                return model;

            logger.LogWarning("类型“{ClassName}”未实现 {Interface}，将使用默认语言模型。",
                className, nameof(ILanguageModel));
        }
        catch (Exception e)
        {
            logger.LogWarning(e, "获取压缩语言模型“{ClassName}”失败，将使用默认语言模型。", className);
        }

        return languageModel;
    }
    protected override async Task OnDestroy()
    {
        ChatBot.ChatSend -= OnChatSend;
        ChatBot.ChatHistoryAdd -= OnChatHistoryAdd;
        ChatBot.TokenUsed -= OnTokenUsed;
        if (vectorizer != null)
            await vectorizer.DisposeAsync();
    }

    string OnChatSend(string message)
    {
        foreach (string keyword in Configuration.RecallHintKeywords)
        {
            if (message.Contains(keyword, StringComparison.OrdinalIgnoreCase))
            {
                return $"{message}\n(提示：如有需要，可以使用<{nameof(MemoryService)}>来尝试回忆往事)";
            }
        }

        return message;
    }
    async void OnChatHistoryAdd(ChatMessageContent content)
    {
        try
        {
            if (Interlocked.Exchange(ref compressing, 1) == 1)
                return; //已在压缩中，跳过本次留待下轮触发

            if (content.Role != AuthorRole.Assistant)
                return; //只在ai说话后整理，这样对话更完整，而且可以避免在ai异常时保持记忆

            //阶段一：先落盘历史并取出快照，随后在快照副本上完成压缩检测与LLM归纳，避免长时间占用真实上下文
            MemoryCompressionPlan? plan;
            ChatHistory snapshot = new();
            await ChatBot.EditChatHistoryAsync(thread => {
                memoryManager.SaveHistory(thread.ChatHistory);
                foreach (var message in thread.ChatHistory)
                    snapshot.Add(message);
                return Task.CompletedTask;
            }, "存储记忆");

            var thinking = Configuration.ThinkingCompress
                ? compressModel.GetThinkingRequester().Rent("记忆压缩")
                : compressModel.GetThinkingRequester().Rent("记忆压缩(轻量)");
            try
            {
                plan = await memoryManager.Analyze(snapshot);
            }
            finally
            {
                thinking.Dispose();
            }

            //阶段二：归纳完成后，原子替换真实上下文
            if (plan != null)
            {
                await ChatBot.EditChatHistoryAsync(async thread => {
                    await memoryManager.Apply(thread.ChatHistory, plan);
                    memoryManager.SaveHistory(thread.ChatHistory);
                }, "应用记忆压缩");
            }
        }
        catch (Exception e)
        {
            logger.LogError(e, "记忆压缩失败");
        }
        finally
        {
            Interlocked.Exchange(ref compressing, 0);
        }
    }

    void OnTokenUsed(TokenUsage usage)
    {
        if (usage.Total < Configuration.TokenWarningThreshold)
            return;

        logger.LogWarning($$"""
                            检测到上下文token已超过警告线，必须进行人工干涉！
                            (当前上下文约 {{usage.Input}} tokens / 警告线 {{Configuration.TokenWarningThreshold}} tokens)
                            1. 检查完整背景中的永久（最高级）记忆，此记忆通常由AI自主记忆，必须由人工删除。
                            2. 如果自动压缩的记忆已达最高级，而造成记忆膨胀，请继续提高最大记忆压缩等级。
                            3. 如果你的模型实际上还有充足的token容量，且未觉得上下文异常，可以提高警告线数值。
                            """);
    }
}

/// <summary>
/// 感知上下文的人设化压缩器
/// </summary>
class AlifeHistoryCompressor(
    ILanguageModel languageModel,
    float probability,
    string promptTemplate) :
    HistoryCompressor
{
    public override async Task<string?> Compress(ChatHistoryAgentThread chatHistoryAgentThread, string range)
    {
        if (Random.Shared.NextSingle() > probability)
            return null;

        ChatHistory history = chatHistoryAgentThread.ChatHistory;
        int startIndex = history.Count;
        string prompt = promptTemplate.Replace("{range}", range);
        try
        {
            history.AddUserMessage(prompt);

            AlifeLog.LogInformation("记忆压缩中......");
            TokenUsage tokenUsage = new();
            Exception? exception = null;
            string response = await languageModel.ChatStreamingAsync(
                chatHistoryAgentThread,
                exceptionThrow: e => exception = e,
                tokenUsed: usage => {
                    tokenUsage += usage;
                });
            AlifeLog.LogInformation("压缩消耗：" + tokenUsage);

            if (exception != null)
                throw new Exception("记忆压缩失败！", innerException: exception);
            if (string.IsNullOrEmpty(response) || response.Length < 100)
                throw new Exception($"记忆压缩失败！压缩结果长度过短：“{response}”");

            return response;
        }
        finally
        {
            history.RemoveRange(startIndex, history.Count - startIndex);
        }
    }
}