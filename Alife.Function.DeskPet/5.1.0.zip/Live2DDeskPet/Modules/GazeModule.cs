using System;
using System.Drawing;
using System.Threading;
using System.Threading.Tasks;
using Alife.Foundation;

namespace Alife.Function.DeskPet;

public class GazeModule : IPetModule, IDisposable
{
    public string JsCode => """
                            messageBus.on('look', (msg) =>{ 
                                model.focus(msg.x, msg.y, msg.instant); 
                            });
                            """;

    readonly PetWindow bridge;
    readonly PetWindow window;
    readonly CancellationTokenSource? cancellationTokenSource;
    DateTime? lastMouseMoveTime;

    public GazeModule(PetWindow bridge, PetWindow window, SubtitleModule subtitleModule)
    {
        this.bridge = bridge;
        this.window = window;

        window.MouseMoved += OnMouseMoved;
        subtitleModule.Showed += OnSubtitleShowed;
        subtitleModule.Hid += OnSubtitleHid;

        cancellationTokenSource = new CancellationTokenSource();
        FocusResetLoop(cancellationTokenSource.Token);
    }

    public void Dispose()
    {
        cancellationTokenSource?.Cancel();
        cancellationTokenSource?.Dispose();
    }


    void OnSubtitleShowed()
    {
        window.MouseMoved -= OnMouseMoved;
        LookCenter();
    }
    void OnSubtitleHid()
    {
        window.MouseMoved += OnMouseMoved;
    }
    void OnMouseMoved()
    {
        Point point = window.CursorScreenPoint;
        Rectangle rectangle = window.Bounds;
        bridge.SendMessage("look", new {
            x = point.X - rectangle.X, y = point.Y - rectangle.Y, instant = false
        });
        lastMouseMoveTime = DateTime.Now;
    }


    async void FocusResetLoop(CancellationToken cancellationToken)
    {
        try
        {
            while (cancellationToken.IsCancellationRequested == false)
            {
                await Task.Delay(500, cancellationToken);
                if (lastMouseMoveTime == null)
                    continue;

                if (DateTime.Now - lastMouseMoveTime.Value > TimeSpan.FromSeconds(3))
                {
                    LookCenter();
                    lastMouseMoveTime = null;
                }
            }
        }
        catch (OperationCanceledException) { }
        catch (Exception e)
        {
            AlifeLog.LogError(e);
        }
    }

    void LookCenter()
    {
        bridge.SendMessage("look", new {
            x = window.Bounds.Width / 2.0f,
            y = window.Bounds.Height / 2.0f,
            instant = false
        });
    }
}