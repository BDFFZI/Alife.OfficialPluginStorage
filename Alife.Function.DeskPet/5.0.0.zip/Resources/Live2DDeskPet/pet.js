// ---- Alife 通用窗口桥（宿主自动注入）----
// 宿主（MAUI/WPF）创建 WebView2 窗口时会在任何页面脚本执行前注入
// window.alifeWindow（见 Alife.Client 的 BridgeScript）。

if (window.alifeWindow) {
    window.messageBus = {
        on: function (type, handler) {
            window.alifeWindow.onMessage(msg => {
                if (msg.type === type)
                    handler(msg)
            });
        },
    };
    window.alifeWindow.nativePostMessage = window.postMessage.bind(window); //保留原生 postMessage
    window.postMessage = function (data) {
        window.alifeWindow.postMessage(data);
    };
}

function formatLogArg(arg) {
    if (arg instanceof Error) return arg.name + ': ' + arg.message + '\n' + (arg.stack || '');
    if (typeof arg === 'object') {
        try {
            return JSON.stringify(arg);
        } catch {
            return String(arg);
        }
    }
    return String(arg);
}

function postLog(level) {
    try {
        var args = Array.prototype.slice.call(arguments, 1);
        postMessage({
            type: 'log',
            level: level,
            text: args.map(formatLogArg).join(' ')
        });
    } catch {
    }
}

{
    var rawWarn = console.warn.bind(console);
    var rawError = console.error.bind(console);
    console.warn = function () {
        postLog.apply(null, ['warn'].concat(Array.prototype.slice.call(arguments)));
        rawWarn.apply(console, arguments);
    };
    console.error = function () {
        postLog.apply(null, ['error'].concat(Array.prototype.slice.call(arguments)));
        rawError.apply(console, arguments);
    };
}

window.addEventListener('error', function (e) {
    var target = e.target;
    if (target && target !== window) {
        postLog('resource-error', target.tagName || 'unknown', target.src || target.href || '');
        return;
    }
    postLog('error', e.message, e.filename + ':' + e.lineno + ':' + e.colno, e.error || '');
}, true);

window.addEventListener('unhandledrejection', function (e) {
    postLog('unhandledrejection', e.reason);
});

// ---- 前端资源注入辅助 ----
function injectCSS(css) {
    var style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
}

function injectHTML(html) {
    var div = document.createElement('div');
    div.innerHTML = html;
    while (div.firstChild) document.body.appendChild(div.firstChild);
}

// ---- 加载模型 ----

messageBus.on('load', function (msg) {
    loadModel(msg.url);
});

const app = new PIXI.Application({
    view: document.getElementById('canvas'),
    autoStart: true,
    resizeTo: window,
    transparent: true,
    backgroundAlpha: 0,
});

let model = null;

// 用户在模型上的追加偏移与缩放（独立于布局基准，窗口 resize/updateLayout 不会重置）
let userScale = 1;
let userOffsetX = 0;
let userOffsetY = 0;

// 将布局基准 + 用户追加变换应用到模型
function applyTransform() {
    if (!model) return;
    const sc = window.innerHeight / model.internalModel.originalHeight;
    model.scale.set(sc * userScale);
    model.position.set(window.innerWidth * 0.5 + userOffsetX, window.innerHeight * 0.48 + userOffsetY);
}

// 光标是否落在角色身上：按 Live2D 命中的 HitAreas 判定（与双击互动同一套区域）。
// 放在这里而不是各模块内，是因为命中测试必须和画布坐标对齐，且鼠标穿透状态下
// 窗口收不到鼠标事件、渲染进程无法自行感知光标，只能由主进程推送坐标后在此判定，
// 各模块共用同一个入口避免重复实现。
window.isOverModelAt = function (x, y) {
    if (!model) return false;
    try {
        return model.hitTest(x, y).length > 0;
    } catch (e) {
        return false;
    }
};

async function loadModel(url) {
    console.log('[Pet] Loading model:', url);
    if (model) app.stage.removeChild(model);
    try {
        model = await PIXI.live2d.Live2DModel.from(url, {autoInteract: false});
        console.log('[Pet] Model loaded successfully');
    } catch (err) {
        console.error('[Pet] Live2D model load failed:', err);
        postMessage({type: 'loaded'});
        return;
    }
    app.stage.addChild(model);

    var updateLayout = function () {
        var s = window.innerHeight / 540;
        document.documentElement.style.setProperty('--ui-scale', s);
        applyTransform();
    };

    model.anchor.set(0.5, 0.5);
    updateLayout();
    model.interactive = true;
    window.addEventListener('resize', updateLayout);

    postMessage({type: 'loaded'});
}

// ---- 初始化完成 ----
postMessage({type: 'init'});

document.addEventListener("mousemove", e => {
    console.log("鼠标屏幕位置:", `${e.screenX}, ${e.screenY}`);
    console.log("鼠标视口位置:", `${e.clientX}, ${e.clientY}`);
    console.log("鼠标网页位置:", `${e.pageX}, ${e.pageY}`);

    console.log("屏幕大小:", `${screen.width} × ${screen.height}`);
    console.log("屏幕可用大小:", `${screen.availWidth} × ${screen.availHeight}`);
    console.log("视口大小:", `${innerWidth} × ${innerHeight}`);
    console.log("浏览器窗口大小:", `${outerWidth} × ${outerHeight}`);
});