using System;

namespace Alife.Function.Auditory;

public interface IAuditoryModel
{
    event Action<string>? Recognized;
    /// <summary>喂入 16kHz 单声道 float 波形，只处理前 length 个采样（数组可复用）。</summary>
    void AcceptWaveform(float[] samples, int length);

    /// <summary>结束当前会话，促使 VAD 输出末尾语音段。</summary>
    void Flush()
    {
    }
}

public interface IAudioRecognizer : IAuditoryModel, IDisposable
{
}

public interface IAudioRecognizerProvider
{
    /// <summary>创建一个新的流式识别器（独立 VAD）。</summary>
    IAudioRecognizer CreateAudioRecognizer();
}
