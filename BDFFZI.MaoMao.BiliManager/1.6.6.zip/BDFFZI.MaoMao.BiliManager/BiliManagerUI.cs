
using System;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Alife.Framework;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace BDFFZI.MaoMao.BiliManager;

/// <summary>
/// B站管理模块自定义UI：显示当前账号信息 + 退出登录/重新扫码按钮
/// </summary>
public class BiliManagerUI : ModuleUIBase<BiliManagerService, BiliManagerConfig>
{
    string? _accountJson;
    string? _qrPath;
    string? _qrDataUrl;
    string _status = "";
    bool _busy;
    string? _avatarDataUrl;
    static string? _cachedAccountJson; // 跨页面打开缓存，秒显登录态
    bool _loading;

    protected override void OnInitialized()
    {
        base.OnInitialized();
        if (_cachedAccountJson != null) _accountJson = _cachedAccountJson; else _loading = true;
        _ = RefreshAsync();
    }

    async Task RefreshAsync()
    {
        if (Module == null) return;
        try
        {
            _accountJson = await Module.RunForUIAsync("account");
            _cachedAccountJson = _accountJson;
            await LoadAvatarAsync();
        }
        catch (Exception ex) { _accountJson = $"{{\"error\":\"{ex.Message}\"}}"; }
        _loading = false;
        StateHasChanged();
    }

    async Task LoadAvatarAsync()
    {
        _avatarDataUrl = null;
        try
        {
            using var doc = JsonDocument.Parse(_accountJson ?? "{}");
            var face = doc.RootElement.TryGetProperty("avatar", out var a) ? a.GetString() : null;
            if (!string.IsNullOrEmpty(face))
            {
                using var http = new HttpClient();
                var bytes = await http.GetByteArrayAsync(face);
                _avatarDataUrl = "data:image/jpeg;base64," + Convert.ToBase64String(bytes);
            }
        }
        catch { }
    }

    async Task LogoutAsync()
    {
        if (Module == null) return;
        _busy = true; _status = "正在退出登录...";
        StateHasChanged();
        try
        {
            _status = await Module.RunForUIAsync("logout");
            _accountJson = null; _avatarDataUrl = null;
            await RefreshAsync();
        }
        catch (Exception ex) { _status = "失败: " + ex.Message; }
        _busy = false; StateHasChanged();
    }

    async Task ReloginAsync()
    {
        if (Module == null) return;
        _busy = true; _status = "正在生成二维码...";
        StateHasChanged();
        try
        {
            string json = await Module.RunForUIAsync("login");
            using var doc = JsonDocument.Parse(json);
            var imgPath = doc.RootElement.TryGetProperty("qrimg", out var q) ? q.GetString() : null;
            if (!string.IsNullOrEmpty(imgPath) && File.Exists(imgPath))
                _qrDataUrl = "data:image/png;base64," + Convert.ToBase64String(File.ReadAllBytes(imgPath));
            else
                _qrDataUrl = null;
            _status = "请用B站APP扫码";
        }
        catch (Exception ex) { _status = "生成失败: " + ex.Message; }
        _busy = false; StateHasChanged();
    }

    async Task PollAsync()
    {
        if (Module == null) return;
        _busy = true;
        try
        {
            string json = await Module.RunForUIAsync("login_poll");
            using var doc = JsonDocument.Parse(json);
            int code = doc.RootElement.TryGetProperty("code", out var c) ? c.GetInt32() : -1;
            _status = code switch
            {
                0 => "登录成功！",
                86090 => "已扫码，请在手机上确认",
                86101 => "等待扫码...",
                86038 => "二维码已过期，请重新生成",
                _ => "状态码: " + code
            };
            if (code == 86038) _qrDataUrl = null;
            if (code == 0) { _qrPath = null; _qrDataUrl = null; await RefreshAsync(); }
        }
        catch (Exception ex) { _status = "失败: " + ex.Message; }
        _busy = false; StateHasChanged();
    }

    protected override void BuildRenderTree(RenderTreeBuilder builder)
    {
        if (_loading && _accountJson == null)
        {
            builder.OpenElement(0, "div");
            builder.AddAttribute(1, "style", "padding:12px;color:#888;font-size:14px;");
            builder.AddContent(2, "正在查询B站登录状态...");
            builder.CloseElement();
            return;
        }
        bool loggedIn = false;
        string uname = "", level = "", coins = "";
        if (_accountJson != null)
        {
            try
            {
                using var doc = JsonDocument.Parse(_accountJson);
                loggedIn = doc.RootElement.TryGetProperty("logged_in", out var li) && li.GetBoolean();
                if (loggedIn)
                {
                    uname = doc.RootElement.TryGetProperty("uname", out var u) ? u.GetString() ?? "" : "";
                    level = doc.RootElement.TryGetProperty("level", out var l) && l.ValueKind == JsonValueKind.Number ? l.GetInt32().ToString() : "-";
                    coins = doc.RootElement.TryGetProperty("coins", out var m) && m.ValueKind == JsonValueKind.Number ? m.GetDouble().ToString("F1") : "-";
                }
            }
            catch { }
        }

        var seq = 0;
        builder.OpenElement(seq++, "div");
        builder.AddAttribute(seq++, "style", "background:var(--alife-bg-subtle);padding:20px;border-radius:12px;border:1px solid var(--alife-border);");

        builder.OpenElement(seq++, "div");
        builder.AddAttribute(seq++, "style", "font-weight:600;margin-bottom:12px;");
        builder.AddContent(seq++, "B站账号");
        builder.CloseElement();

        if (loggedIn)
        {
            builder.OpenElement(seq++, "div");
            builder.AddAttribute(seq++, "style", "display:flex;align-items:center;gap:12px;");
            builder.OpenElement(seq++, "img");
            builder.AddAttribute(seq++, "src", _avatarDataUrl ?? "");
            builder.AddAttribute(seq++, "style", "width:48px;height:48px;border-radius:50%;object-fit:cover;");
            builder.CloseElement();
            builder.OpenElement(seq++, "div");
            builder.OpenElement(seq++, "div");
            builder.AddAttribute(seq++, "style", "font-weight:600;");
            builder.AddContent(seq++, uname);
            builder.CloseElement();
            builder.OpenElement(seq++, "div");
            builder.AddAttribute(seq++, "style", "font-size:12px;color:var(--alife-text-secondary);");
            builder.AddContent(seq++, $"等级 Lv{level} · 硬币 {coins}");
            builder.CloseElement();
            builder.CloseElement();
            builder.CloseElement();

            builder.OpenElement(seq++, "button");
            builder.AddAttribute(seq++, "style", "margin-top:12px;padding:6px 16px;border-radius:8px;border:1px solid #e5e5e5;background:#fff;cursor:pointer;" + (_busy ? "opacity:.5;" : ""));
            builder.AddAttribute(seq++, "onclick", EventCallback.Factory.Create(this, LogoutAsync));
            builder.AddAttribute(seq++, "disabled", _busy);
            builder.AddContent(seq++, "退出登录");
            builder.CloseElement();
        }
        else
        {
            builder.OpenElement(seq++, "div");
            builder.AddAttribute(seq++, "style", "color:var(--alife-text-secondary);");
            builder.AddContent(seq++, "未登录");
            builder.CloseElement();

            if (_qrDataUrl == null)
            {
                builder.OpenElement(seq++, "button");
                builder.AddAttribute(seq++, "style", "margin-top:12px;padding:6px 16px;border-radius:8px;border:none;background:#fb7299;color:#fff;cursor:pointer;" + (_busy ? "opacity:.5;" : ""));
                builder.AddAttribute(seq++, "onclick", EventCallback.Factory.Create(this, ReloginAsync));
                builder.AddAttribute(seq++, "disabled", _busy);
                builder.AddContent(seq++, "扫码登录");
                builder.CloseElement();
            }
        }

        if (_qrDataUrl != null)
        {
            builder.OpenElement(seq++, "img");
            builder.AddAttribute(seq++, "src", _qrDataUrl);
            builder.AddAttribute(seq++, "style", "margin-top:12px;width:180px;height:180px;border:1px solid var(--alife-border);border-radius:8px;");
            builder.CloseElement();
            builder.OpenElement(seq++, "button");
            builder.AddAttribute(seq++, "style", "margin-top:8px;padding:6px 16px;border-radius:8px;border:none;background:#fb7299;color:#fff;cursor:pointer;" + (_busy ? "opacity:.5;" : ""));
            builder.AddAttribute(seq++, "onclick", EventCallback.Factory.Create(this, PollAsync));
            builder.AddAttribute(seq++, "disabled", _busy);
            builder.AddContent(seq++, "我扫好了");
            builder.CloseElement();
        }

        if (!string.IsNullOrEmpty(_status))
        {
            builder.OpenElement(seq++, "div");
            builder.AddAttribute(seq++, "style", "margin-top:10px;font-size:13px;color:var(--alife-text-secondary);");
            builder.AddContent(seq++, _status);
            builder.CloseElement();
        }

        builder.CloseElement();
        builder.AddContent(seq++, DefaultUI);
    }
}
