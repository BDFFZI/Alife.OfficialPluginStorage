# -*- coding: utf-8 -*-
"""B站管理脚本：账号/稿件/评论/数据/投稿/搜索/弹幕/点赞/收藏/投币/关注/发弹幕/动态/私信/删评。凭证读插件目录bili_account.json（login命令扫码生成）"""
import json, os, sys, urllib.request, urllib.parse, time, hashlib, re
sys.stdout.reconfigure(encoding='utf-8')

# Storage目录从脚本位置动态推导：脚本在 Storage\Plugins\插件名\ 下，上两级即Storage
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_acc_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bili_account.json")
if os.path.exists(_acc_path):
    _acc = json.load(open(_acc_path, encoding="utf-8"))
    SESSDATA, JCT, UID = _acc["SESSDATA"], _acc["bili_jct"], _acc["mid"]
    COOKIE = f"SESSDATA={SESSDATA}; bili_jct={JCT}; DedeUserID={UID}"
else:
    SESSDATA, JCT, UID = "", "", 0
    COOKIE = ""


def _save_acc(d):
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bili_account.json")
    json.dump(d, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

def _qrkey_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "login_qr_key.txt")


def qrcode_login_start():
    # 生成扫码登录二维码图片落盘，立即返回不等待扫码。之后用 login_poll 查询状态
    try:
        import qrcode
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "qrcode", "-q"])
        import qrcode
    d = req("https://passport.bilibili.com/x/passport-login/web/qrcode/generate")
    qr_url, ok = d["data"]["url"], d["data"]["qrcode_key"]
    img_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "login_qr.png")
    # 旧码图可能被看图软件锁死导致Errno22，save前先强制删旧文件
    if os.path.exists(img_path):
        try:
            os.remove(img_path)
        except OSError:
            img_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "login_qr_2.png")
    qrcode.make(qr_url).save(img_path)
    with open(_qrkey_path(), "w", encoding="utf-8") as f:
        f.write(ok)
    print(json.dumps({"code": 0, "qrimg": img_path, "msg": "二维码已生成，用LoadImage查看并展示给用户扫码，然后用LoginPoll查询扫码状态（约2~5秒一次）"}, ensure_ascii=False))


def _login_via_crossdomain(u):
    # 新版登录：回调url形如 crossDomain?ticket=...，跟随重定向链收集Set-Cookie
    try:
        import requests
        s = requests.Session()
        s.headers.update({"User-Agent": UA, "Referer": "https://passport.bilibili.com/"})
        r = s.get(u, timeout=15, allow_redirects=True)
        ck = s.cookies.get_dict()
        if "SESSDATA" in ck:
            return {"SESSDATA": ck["SESSDATA"], "bili_jct": ck.get("bili_jct", ""), "mid": int(ck.get("DedeUserID", 0) or 0)}
        # 重定向链没给，再试页面里埋的gourl跳转
        m = re.search(r'gourl=([^&"]+)', u)
        if m:
            import urllib.parse as _up
            g = _up.unquote(m.group(1))
            r2 = s.get(g, timeout=15, allow_redirects=True)
            ck = s.cookies.get_dict()
            if "SESSDATA" in ck:
                return {"SESSDATA": ck["SESSDATA"], "bili_jct": ck.get("bili_jct", ""), "mid": int(ck.get("DedeUserID", 0) or 0)}
    except Exception as e:
        print(json.dumps({"code": -3, "msg": "crossDomain异常: " + repr(e)}, ensure_ascii=False))
    return None


def qrcode_login_poll():
    # 单次查询扫码状态：86101未扫码/86090已扫未确认/86038已过期/0成功落凭据
    kp = _qrkey_path()
    if not os.path.exists(kp):
        print(json.dumps({"code": -1, "msg": "还没有发起登录，请先调用 Login 生成二维码"}, ensure_ascii=False))
        return
    ok = open(kp, encoding="utf-8").read().strip()
    r = req("https://passport.bilibili.com/x/passport-login/web/qrcode/poll?qrcode_key=" + urllib.parse.quote(ok), method="GET")
    c = r["data"]["code"]
    if c == 0:
        u = r["data"]["url"]
        # 回调参数可能在fragment(#)里而非query(?)里，两段都解析合并
        pu = urllib.parse.urlparse(u)
        q = {}
        for src in (urllib.parse.parse_qs(pu.query), urllib.parse.parse_qs(pu.fragment)):
            q.update(src)
        if "SESSDATA" not in q:
            # 新版流程：回调url带ticket，需跟随crossDomain重定向链从Set-Cookie收集凭据
            acc = _login_via_crossdomain(u)
            if not acc:
                print(json.dumps({"code": -2, "msg": "回调URL缺凭据参数且crossDomain链未取到cookie，原始url: " + u}, ensure_ascii=False))
                return
        else:
            acc = {"SESSDATA": q["SESSDATA"][0], "bili_jct": q["bili_jct"][0], "mid": int(q["DedeUserID"][0])}
        _save_acc(acc)
        os.remove(kp)
        img_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "login_qr.png")
        if os.path.exists(img_path):
            os.remove(img_path)
        print(json.dumps({"code": 0, "msg": "登录成功", "mid": acc["mid"]}, ensure_ascii=False))
    elif c == 86038:
        os.remove(kp)
        print(json.dumps({"code": 86038, "msg": "二维码已过期，请重新调用 Login"}, ensure_ascii=False))
    elif c == 86090:
        print(json.dumps({"code": 86090, "msg": "已扫码，等待用户手机确认"}, ensure_ascii=False))
    else:
        print(json.dumps({"code": c, "msg": "等待扫码中"}, ensure_ascii=False))


UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"

def req(url, data=None, method=None, json_body=None):
    if json_body is not None:
        body = json.dumps(json_body).encode()
        ct = "application/json"
    else:
        body = urllib.parse.urlencode(data).encode() if isinstance(data, dict) else data
        ct = "application/x-www-form-urlencoded"
    r = urllib.request.Request(url, data=body, method=method, headers={
        "User-Agent": UA, "Referer": "https://www.bilibili.com/", "Cookie": COOKIE,
        "Content-Type": ct})
    with urllib.request.urlopen(r, timeout=20) as resp:
        return json.loads(resp.read().decode("utf-8"))

# ---------- 原有能力 ----------
def get_archives(pn=1, ps=20):
    d = req(f"https://member.bilibili.com/x/web/archives?status=is_pubing,pubed,not_pubed&pn={pn}&ps={ps}")
    out = []
    for a in (d.get("data", {}).get("arc_audits") or []):
        arc = a.get("Archive", {})
        out.append({"bvid": arc.get("bvid"), "aid": arc.get("aid"), "title": arc.get("title"),
                    "state": arc.get("state_desc") or arc.get("state"),
                    "play": (a.get("stat") or {}).get("view"),
                    "like": (a.get("stat") or {}).get("like"),
                    "comment": (a.get("stat") or {}).get("reply")})
    return {"code": d.get("code"), "count": d.get("data", {}).get("page", {}).get("count"), "list": out}

def get_comments(aid, pn=1, ps=20, sort=2):
    d = req(f"https://api.bilibili.com/x/v2/reply?type=1&oid={aid}&sort={sort}&pn={pn}&ps={ps}")
    out = []
    for c in (d.get("data", {}).get("replies") or []):
        m = c.get("member", {})
        out.append({"rpid": c.get("rpid"), "user": m.get("uname"), "uid": m.get("mid"),
                    "content": c.get("content", {}).get("message"), "like": c.get("like"),
                    "root": c.get("root"), "parent": c.get("parent")})
    return {"code": d.get("code"), "count": d.get("data", {}).get("page", {}).get("count") if d.get("data") else 0, "list": out}

def reply_comment(aid, message, root=0, parent=0, at_uid=0, at_name=""):
    """发评论/回复。at_uid+at_name实现真@（message需含"@名字 "字样）"""
    form = {"type": 1, "oid": aid, "message": message, "root": root, "parent": parent, "csrf": JCT}
    if at_uid:
        form["at_uids"] = str(at_uid)
        form["at_name_to_mid"] = json.dumps({f"@{at_name} ": str(at_uid)})
    return req("https://api.bilibili.com/x/v2/reply/add", form)

def delete_comment(aid, rpid):
    return req("https://api.bilibili.com/x/v2/reply/del", {"type": 1, "oid": aid, "rpid": rpid, "csrf": JCT})

def get_video_stat(bvid):
    d = req(f"https://api.bilibili.com/x/web-interface/view?bvid={bvid}")
    data = d.get("data") or {}
    s = data.get("stat", {})
    return {"code": d.get("code"), "title": data.get("title"), "aid": data.get("aid"),
            "cid": data.get("cid"), "view": s.get("view"), "like": s.get("like"),
            "coin": s.get("coin"), "favorite": s.get("favorite"), "reply": s.get("reply"),
            "danmaku": s.get("danmaku"), "share": s.get("share"), "desc": data.get("desc")}

# ---------- 新增：搜索 ----------
def _req_nocookie(url):
    r = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": "https://www.bilibili.com/"})
    with urllib.request.urlopen(r, timeout=20) as resp:
        return json.loads(resp.read().decode("utf-8"))

def _get_buvid():
    # 搜索接口412风控需要buvid指纹cookie，从finger/spi匿名获取
    try:
        d = _req_nocookie("https://api.bilibili.com/x/frontend/finger/spi")
        b3 = (d.get("data") or {}).get("b_3", "")
        b4 = (d.get("data") or {}).get("b_4", "")
        return f"buvid3={b3}; buvid4={b4}"
    except Exception:
        return ""

def search_videos(keyword, pn=1, order="totalrank"):
    kw = urllib.parse.quote(keyword)
    url = f"https://api.bilibili.com/x/web-interface/search/type?search_type=video&keyword={kw}&order={order}&page={pn}"
    r = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": "https://search.bilibili.com/", "Cookie": _get_buvid()})
    with urllib.request.urlopen(r, timeout=20) as resp:
        d = json.loads(resp.read().decode("utf-8"))
    out = []
    for v in ((d.get("data") or {}).get("result") or [])[:20]:
        t = v.get("title", "")
        t = re.sub(r"</?em[^>]*>", "", t)
        out.append({"bvid": v.get("bvid"), "title": t, "author": v.get("author"),
                    "play": v.get("play"), "danmaku": v.get("video_review"),
                    "duration": v.get("duration"), "pubdate": v.get("pubdate")})
    return {"code": d.get("code"), "numResults": (d.get("data") or {}).get("numResults"), "list": out}

# ---------- 新增：弹幕 ----------
def get_danmaku(bvid, limit=60):
    import gzip
    d = get_video_stat(bvid)
    if d.get("code") != 0:
        return d
    cid = d.get("cid")
    r = urllib.request.Request(f"https://comment.bilibili.com/{cid}.xml",
                               headers={"User-Agent": UA, "Referer": "https://www.bilibili.com/"})
    with urllib.request.urlopen(r, timeout=20) as resp:
        raw = resp.read()
    import zlib
    if raw[:2] == b"\x1f\x8b":
        raw = gzip.decompress(raw)
    else:
        try:
            raw = zlib.decompress(raw, -15)
        except Exception:
            pass
    xml = raw.decode("utf-8", "ignore")
    items = re.findall(r'<d p="([^"]+)">([^<]+)</d>', xml)
    out = [{"t": float(p.split(",")[0]), "text": x} for p, x in items[:limit]]
    return {"code": 0, "bvid": bvid, "list": out}

def send_danmaku(bvid, text, progress_ms=0):
    d = get_video_stat(bvid)
    d2 = {"type": 1, "oid": d.get("cid"), "msg": text, "aid": d.get("aid"),
          "progress": int(progress_ms), "rnd": 1000000, "mode": 1, "fontsize": 25,
          "color": 16777215, "pool": 0, "csrf": JCT, "csrf_token": JCT}
    return req("https://api.bilibili.com/x/v2/dm/post", d2)


def req_json(url, json_body, extra):
    body = json.dumps(dict(json_body, **extra)).encode()
    r = urllib.request.Request(url, data=body, headers={
        "User-Agent": UA, "Referer": "https://www.bilibili.com/",
        "Cookie": COOKIE, "Content-Type": "application/json"})
    with urllib.request.urlopen(r, timeout=20) as resp:
        return json.load(resp)

# ---------- 新增：点赞/投币/收藏/关注 ----------
def like(bvid, is_like=1):
    """is_like: 1点赞 2取消。取消需要先拿aid再传like=2"""
    d = get_video_stat(bvid)
    return req("https://api.bilibili.com/x/web-interface/archive/like",
               {"aid": d.get("aid"), "like": is_like, "csrf": JCT, "csrf_token": JCT})

def coin_add(bvid, multiply=1, with_like=1):
    d = get_video_stat(bvid)
    return req("https://api.bilibili.com/x/web-interface/coin/add",
               {"aid": d.get("aid"), "multiply": multiply, "select_like": with_like,
                "csrf": JCT, "csrf_token": JCT})

def favorite(bvid):
    d = get_video_stat(bvid)
    fl = req("https://api.bilibili.com/x/v3/fav/folder/created/list-all?up_mid=" + str(UID))
    mlist = ((fl.get("data") or {}).get("list") or [])
    if not mlist:
        return {"error": "没有可用收藏夹"}
    fid = mlist[0]["id"]
    return req("https://api.bilibili.com/x/v3/fav/resource/deal",
               {"rid": d.get("aid"), "type": 2, "fid": fid, "add_media_ids": str(fid),
                "csrf": JCT, "csrf_token": JCT})

def follow(mid_num, act=1):
    return req("https://api.bilibili.com/x/relation/modify",
               {"fid": mid_num, "act": act, "re_src": 11, "csrf": JCT, "csrf_token": JCT})

# ---------- 新增：动态/私信 ----------
def post_dynamic(text):
    payload = {"dyn_req": {"content": [{"dyn_type": 1, "text_contents": [
        {"nodes": [{"type": "TEXT", "rid": -1, "text": text}]}]}]}}
    return req("https://api.bilibili.com/x/dynamic/feed/dyn/send?csrf=" + JCT, json_body=payload)

def send_private_msg(receiver_uid, text):
    import random as _r
    _t = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx"
    dev_id = "".join((format(_r.randint(0,15),'X') if c=="x" else format(3&_r.randint(0,15)|8,'X')) if c in "xy" else c for c in _t)
    return req("https://api.vc.bilibili.com/web_im/v1/web_im/send_msg",
               {"msg[sender_uid]": UID, "msg[receiver_id]": receiver_uid, "msg[receiver_type]": 1,
                "msg[msg_type]": 1, "msg[msg_status]": 0,
                "msg[content]": json.dumps({"content": text}, ensure_ascii=False),
                "msg[timestamp]": int(time.time()), "msg[dev_id]": dev_id,
                "csrf": JCT, "csrf_token": JCT})

def get_sessions():
    d = req("https://api.vc.bilibili.com/session_svr/v1/session_svr/get_sessions?session_type=1&size=20")
    out = []
    for s in (d.get("data") or {}).get("session_list") or []:
        tk = s.get("talker_id")
        out.append({"talker_id": tk, "unread": s.get("unread_count"),
                    "last_msg": ((s.get("last_message") or {}).get("content") or {})})
    return {"sessions": out}

def fetch_session_msgs(talker_id, size=20):
    d = req("https://api.vc.bilibili.com/svr_sync/v1/svr_sync/fetch_session_msgs?sender_device_id=1&talker_id=%s&session_type=1&size=%d&build=0&mobi_app=web" % (talker_id, size))
    out = []
    for m in (d.get("data") or {}).get("messages") or []:
        out.append({"sender": m.get("sender_uid"), "time": m.get("timestamp"),
                    "content": m.get("content")})
    return {"messages": out}

# ---------- 新增：抽帧看片 ----------
FFMPEG_PATH = os.path.join(BASE, "Tools", "ffmpeg.exe")

# 镜像清单与 presents.BiliScroll ToolsFetcher.cs 同源（zip包，已核实可用）
FFMPEG_URLS = [
    "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip",
    "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip",
    "https://gh-proxy.com/https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip",
]

def _ensure_ffmpeg():
    """确保ffmpeg可用：本地Tools有就用，常见位置/PATH兜底，都没有才按镜像逐个下载"""
    if os.path.exists(FFMPEG_PATH):
        return FFMPEG_PATH
    # 常见位置兜底（如BiliScroll装过的tools目录）
    import glob as _g
    for pat in (os.path.join(BASE, "BiliScrollTools", "ffmpeg.exe"),
                os.path.join(BASE, "Plugins", "presents.BiliScroll", "tools", "**", "ffmpeg.exe")):
        hits = _g.glob(pat, recursive=True)
        if hits:
            return hits[0]
    import subprocess as _sp
    try:
        _sp.run(["ffmpeg", "-version"], capture_output=True, timeout=15)
        return "ffmpeg"
    except Exception:
        pass
    os.makedirs(os.path.dirname(FFMPEG_PATH), exist_ok=True)
    import zipfile as _zf
    for url in FFMPEG_URLS:
        try:
            print(f"下载ffmpeg: {url}", file=sys.stderr)
            zpath = FFMPEG_PATH + ".zip.tmp"
            r = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(r, timeout=600) as resp, open(zpath, "wb") as f:
                while True:
                    chunk = resp.read(1024 * 256)
                    if not chunk:
                        break
                    f.write(chunk)
            # 解压取ffmpeg.exe（zip内可能在子目录）
            with _zf.ZipFile(zpath) as z:
                for n in z.namelist():
                    if n.lower().endswith("ffmpeg.exe"):
                        with z.open(n) as s, open(FFMPEG_PATH + ".tmp", "wb") as d:
                            while True:
                                c = s.read(1024 * 256)
                                if not c:
                                    break
                                d.write(c)
                        break
            os.remove(zpath)
            if os.path.exists(FFMPEG_PATH + ".tmp") and os.path.getsize(FFMPEG_PATH + ".tmp") > 10 * 1024 * 1024:
                os.replace(FFMPEG_PATH + ".tmp", FFMPEG_PATH)
                return FFMPEG_PATH
            raise RuntimeError("解压后未找到ffmpeg.exe")
        except Exception as e:
            print(f"镜像失败 {url}: {e}", file=sys.stderr)
            continue
    raise RuntimeError("ffmpeg下载失败，所有镜像均不可用")

def extract_frames(bvid, count=12):
    """下载视频并均匀抽帧拼成网格图，返回图片路径。count范围4~24"""
    import subprocess, glob as _glob
    count = max(4, min(24, int(count)))
    d = get_video_stat(bvid)
    if d.get("code") != 0:
        return d
    cid, dur = d.get("cid"), d.get("duration") or 120
    ff = _ensure_ffmpeg()
    out_dir = os.path.join(BASE, "Temp", f"bili_frames_{bvid}")
    os.makedirs(out_dir, exist_ok=True)
    vid = os.path.join(out_dir, "video.mp4")
    if not os.path.exists(vid) or os.path.getsize(vid) < 100000:
        # 拿播放流
        r = urllib.request.Request(
            f"https://api.bilibili.com/x/player/playurl?bvid={bvid}&cid={cid}&qn=32&fnval=0",
            headers={"User-Agent": UA, "Referer": "https://www.bilibili.com/", "Cookie": COOKIE})
        pd = json.loads(urllib.request.urlopen(r, timeout=20).read().decode())
        if pd.get("code") != 0:
            return {"code": pd.get("code"), "error": "拿播放流失败"}
        # durl是多分片数组（长视频会被切段），必须全下再拼接，否则后面时段全是黑帧
        durls = pd["data"]["durl"]
        parts = []
        for di, du in enumerate(durls):
            pt = os.path.join(out_dir, f"part_{di}.mp4")
            req2 = urllib.request.Request(du["url"], headers={
                "User-Agent": UA, "Referer": "https://www.bilibili.com/", "Cookie": COOKIE, "Range": "bytes=0-"})
            for attempt in range(3):
                try:
                    with urllib.request.urlopen(req2, timeout=180) as resp, open(pt + ".part", "wb") as f:
                        while True:
                            chunk = resp.read(256 * 1024)
                            if not chunk:
                                break
                            f.write(chunk)
                    break
                except (http.client.IncompleteRead, Exception):
                    if attempt == 2:
                        raise
                    time.sleep(2)
            os.replace(pt + ".part", pt)
            parts.append(pt)
        if len(parts) == 1:
            os.replace(parts[0], vid)
        else:
            lst = os.path.join(out_dir, "concat.txt")
            with open(lst, "w", encoding="utf-8") as f:
                for pt in parts:
                    f.write("file '" + pt.replace("\\", "/") + "'\n")
            subprocess.run([ff, "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", vid],
                           capture_output=True, timeout=180)
            for pt in parts:
                os.remove(pt)
    grid = os.path.join(out_dir, "grid.jpg")
    cols = 4 if count <= 12 else 6
    rows = 3 if count <= 12 else 4
    fps = f"{count}/{max(dur-2, 1)}"
    subprocess.run([ff, "-y", "-i", vid, "-vf", f"fps={fps},scale=480:-1,tile={cols}x{rows}",
                    "-frames:v", "1", grid], capture_output=True, timeout=180)
    if not os.path.exists(grid):
        return {"code": -1, "error": "ffmpeg抽帧失败"}
    return {"code": 0, "bvid": bvid, "title": d.get("title"), "grid": grid, "count": count}

# ---------- 投稿（原有 upos 逻辑保留） ----------
def _upos_req(url, method="GET", headers=None, data=None):
    h = {"User-Agent": UA, "Referer": "https://member.bilibili.com/", "Cookie": COOKIE}
    if headers:
        h.update(headers)
    r = urllib.request.Request(url, data=data, method=method, headers=h)
    with urllib.request.urlopen(r, timeout=120) as resp:
        return resp.read().decode("utf-8")

def _add_archive(payload):
    return req("https://member.bilibili.com/x/vu/web/add?csrf=" + JCT, json_body=payload)

def submit_video(file_path, title, tid, tag, desc="", cover="", copyright=1):
    size = os.path.getsize(file_path)
    fname = os.path.basename(file_path)
    pu = req(f"https://member.bilibili.com/preupload?name={urllib.parse.quote(fname)}&size={size}"
             f"&r=upos&profile=ugcupos/bup&ssl=0&version=2.14.0&build=2140000")
    if pu.get("OK") != 1:
        raise Exception("preupload失败: " + json.dumps(pu, ensure_ascii=False)[:300])
    upos_uri = pu["upos_uri"].replace("upos://", "")
    url = "https:" + pu["endpoint"] + "/" + upos_uri
    auth = pu["auth"]
    biz_id = pu["biz_id"]
    chunk_size = pu.get("chunk_size", 10485760)
    init = json.loads(_upos_req(f"{url}?uploads&output=json", method="POST", headers={"X-Upos-Auth": auth}))
    upload_id = init.get("upload_id")
    if not upload_id:
        raise Exception("init失败: " + json.dumps(init, ensure_ascii=False)[:300])
    chunks = (size + chunk_size - 1) // chunk_size
    parts = []
    with open(file_path, "rb") as f:
        for i in range(chunks):
            data = f.read(chunk_size)
            start = i * chunk_size
            end = start + len(data)
            q = (f"uploadId={upload_id}&chunks={chunks}&total={size}&chunk={i}"
                 f"&size={len(data)}&partNumber={i+1}&start={start}&end={end}")
            code = _upos_req(f"{url}?{q}", method="PUT",
                             headers={"X-Upos-Auth": auth, "Content-Type": "application/octet-stream"}, data=data)
            if "MULTIPART_PUT_SUCCESS" in code or code.strip() == "":
                parts.append({"partNumber": i + 1, "eTag": "etag"})
    cq = (f"name={urllib.parse.quote(fname)}&uploadId={upload_id}&biz_id={biz_id}"
          f"&output=json&profile=ugcupos/bup")
    comp = json.loads(_upos_req(f"{url}?{cq}", method="POST",
                                headers={"X-Upos-Auth": auth, "Content-Type": "application/json"},
                                data=json.dumps({"parts": parts}).encode()))
    if comp.get("OK") != 1:
        raise Exception("合并失败: " + json.dumps(comp, ensure_ascii=False)[:300])
    stem = os.path.splitext(os.path.basename(upos_uri.split("?")[0]))[0]
    payload = {
        "copyright": copyright, "source": "", "tid": tid, "cover": cover,
        "title": title, "desc_format_id": 0, "desc": desc, "dynamic": "",
        "tag": tag, "videos": [{"filename": stem, "title": title, "desc": ""}],
        "dtime": None, "interactive": 0, "act_reserve_create": 0,
        "no_disturbance": 0, "no_reprint": 1, "open_elec": 1,
        "subtitle": {"open": 0, "lan": ""},
    }
    return _add_archive(payload)

# ---------- 入口 ----------
# ---------- 新增：投稿功能 ----------
def archive_pre():
    """分区表+投稿预备信息"""
    r = urllib.request.Request("https://member.bilibili.com/x/vupre/web/archive/pre", headers={
        "User-Agent": UA, "Cookie": COOKIE, "Referer": "https://member.bilibili.com/"})
    with urllib.request.urlopen(r, timeout=15) as resp:
        d = json.load(resp)
    out = []
    for g in d.get("data", {}).get("typelist", []):
        out.append({"name": g["name"], "children": [{"tid": c["id"], "name": c["name"]} for c in g.get("children", [])]})
    return {"code": 0, "typelist": out}

def _upos_upload(bvid, filepath, title):
    """完整上传：preupload -> 分片PUT -> commit。返回OK"""
    import os as _os
    fp_ = _os.path.abspath(filepath)
    size = _os.path.getsize(fp_)
    import urllib.parse as up
    name = _os.path.basename(fp_)
    q = up.urlencode({"name": name, "size": size, "r": "upos", "profile": "ugcupos/bup",
                      "ssl": 0, "version": "2.14.0", "build": 2140000, "upcdn": "bda2",
                      "probe_version": "20221109", "os": "upos", "zone": "cs"})
    try:
        pre = req("https://member.bilibili.com/preupload?" + q, {})
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")[:300]
        return {"code": e.code, "preupload_err": body}
    if not pre.get("OK"):
        return pre
    upos_key = pre.get("upos_key") or pre.get("upos_uri", "").replace("upos://", "")
    auth = pre["auth"]
    endpoint = pre.get("endpoint", "")
    os_ = pre.get("os", "")
    uploader = "https:" + endpoint if endpoint.startswith("//") else ("https://" + endpoint if endpoint and not endpoint.startswith("http") else endpoint)
    # upos分片上传：PUT /{upos_key}/ {partno}?uploadid=...&os=...&profile=ugcfx/bup
    upload_id = ""
    # init
    init_url = f"{uploader}/{upos_key}?uploads&output=json"
    r = urllib.request.Request(init_url, method="POST", data=b"", headers={
        "X-Upos-Auth": auth, "X-Upos-Meta-Mode": "meta", "X-Upos-Idc": "bda2",
        "User-Agent": UA, "Referer": "https://member.bilibili.com/"})
    idata = json.load(urllib.request.urlopen(r, timeout=15))
    if idata.get("OK") != 1:
        return {"code": -1, "init": idata}
    upload_id = idata["upload_id"]
    # 分片PUT（4MB一片）
    chunk = 4 * 1024 * 1024
    parts = []
    idx = 0
    with open(fp_, "rb") as f:
        while True:
            data = f.read(chunk)
            if not data:
                break
            idx += 1
            purl = f"{uploader}/{upos_key}?partNumber={idx}&uploadid={upload_id}&os={os_}&profile=ugcupos/bup"
            pr = urllib.request.Request(purl, data=data, method="PUT", headers={"X-Upos-Auth": auth})
            urllib.request.urlopen(pr, timeout=60).read()
            parts.append({"partNumber": idx, "eTag": "etag"})
    # commit
    cbody = {"parts": [{"partNumber": p["partNumber"], "eTag": "etag"} for p in parts]}
    biz_id = pre.get("biz_id", 5)
    curl = f"{uploader}/{upos_key}?name={up.quote(name)}&uploadId={upload_id}&biz_id={biz_id}&output=json&profile=ugcupos/bup&os={os_}"
    cr = urllib.request.Request(curl, data=json.dumps(cbody).encode(), method="POST",
                                headers={"X-Upos-Auth": auth, "Content-Type": "application/json"})
    cres = json.load(urllib.request.urlopen(cr, timeout=30))
    if cres.get("OK") != 1:
        return {"code": -2, "commit": cres}
    return {"code": 0, "bili_filename": upos_key, "OK": True}

def upload_video(filepath, part_title=""):
    """上传视频文件到B站（暂存，不投稿）"""
    import os as _os
    if not _os.path.exists(_os.path.abspath(filepath)):
        return {"code": -1, "message": "文件不存在"}
    bvid = "V" + hashlib.md5((str(time.time()) + _os.path.abspath(filepath)).encode()).hexdigest()[:10].upper()
    t0 = time.time()
    res = _upos_upload(bvid, filepath, part_title)
    res["elapsed"] = round(time.time() - t0, 1)
    return res

def submit_archive(title, tid, tag, desc, bili_filename, cover_url="", copyright_=1, source=""):
    """提交稿件。bili_filename来自upload_video返回（自动去后缀）。
    端点=老接口x/vu/web/add?csrf=（add/v3对API请求一律-111，勿用）"""
    fn = bili_filename.rsplit(".", 1)[0] if "." in bili_filename else bili_filename
    body = {"copyright": int(copyright_), "source": source, "tid": int(tid), "cover": cover_url,
            "title": title, "desc_format_id": 0, "desc": desc, "dynamic": "",
            "tag": tag, "videos": [{"filename": fn, "title": title, "desc": ""}],
            "dtime": None, "interactive": 0, "act_reserve_create": 0,
            "no_disturbance": 0, "no_reprint": 1, "open_elec": 1, "subtitle": {"open": 0, "lan": ""}}
    r = urllib.request.Request(f"https://member.bilibili.com/x/vu/web/add?csrf={JCT}",
                               data=json.dumps(body).encode(), method="POST",
                               headers={"User-Agent": UA, "Referer": "https://member.bilibili.com/",
                                        "Cookie": COOKIE, "Content-Type": "application/json"})
    with urllib.request.urlopen(r, timeout=30) as resp:
        return json.load(resp)

def cover_up(filepath):
    """上传封面，返回url"""
    import base64 as b64
    with open(filepath, "rb") as f:
        data = "data:image/png;base64," + b64.b64encode(f.read()).decode()
    return req("https://member.bilibili.com/x/vu/web/cover/up", {"cover": data, "csrf": JCT})



def get_account_status():
    """读本地凭据并用nav接口验证，返回账号信息"""
    if not SESSDATA:
        return {"logged_in": False}
    try:
        d = req("https://api.bilibili.com/x/web-interface/nav", None, method="GET")
        data = d.get("data", {}) or {}
        if not data.get("isLogin"):
            return {"logged_in": False, "expired": True}
        return {"logged_in": True, "mid": data.get("mid"), "uname": data.get("uname"),
                "avatar": data.get("face"), "level": (data.get("levelInfo") or {}).get("current_level"),
                "coins": data.get("money")}
    except Exception as e:
        return {"logged_in": False, "error": str(e)[:200]}

def logout():
    """删除本地凭据文件，退出登录"""
    if os.path.exists(_acc_path):
        os.remove(_acc_path)
        return {"ok": True, "message": "已退出登录"}
    return {"ok": False, "message": "本来就没登录"}

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "help"
    a = sys.argv
    if cmd == "account":
        print(json.dumps(get_account_status(), ensure_ascii=False))
    elif cmd == "logout":
        print(json.dumps(logout(), ensure_ascii=False))
    elif cmd == "login":
        qrcode_login_start()
    elif cmd == "login_poll":
        qrcode_login_poll()
    elif cmd == "archives":
        print(json.dumps(get_archives(), ensure_ascii=False))
    elif cmd == "comments":
        print(json.dumps(get_comments(int(a[2])), ensure_ascii=False))
    elif cmd == "frames":
        print(json.dumps(extract_frames(a[2], int(a[3]) if len(a) > 3 else 12), ensure_ascii=False))
    elif cmd == "stat":
        print(json.dumps(get_video_stat(a[2]), ensure_ascii=False))
    elif cmd == "search":
        kw = a[2]
        order = a[3] if len(a) > 3 else "totalrank"
        print(json.dumps(search_videos(kw, order=order), ensure_ascii=False))
    elif cmd == "danmaku":
        print(json.dumps(get_danmaku(a[2]), ensure_ascii=False))
    elif cmd == "danmaku_send":
        print(json.dumps(send_danmaku(a[2], a[3], int(a[4]) if len(a) > 4 else 0), ensure_ascii=False))
    elif cmd == "like":
        print(json.dumps(like(a[2]), ensure_ascii=False))
    elif cmd == "coin":
        print(json.dumps(coin_add(a[2], int(a[3]) if len(a) > 3 else 1), ensure_ascii=False))
    elif cmd == "favorite":
        print(json.dumps(favorite(a[2]), ensure_ascii=False))
    elif cmd == "follow":
        print(json.dumps(follow(int(a[2])), ensure_ascii=False))
    elif cmd == "dynamic":
        print(json.dumps(post_dynamic(a[2]), ensure_ascii=False))
    elif cmd == "pm":
        print(json.dumps(send_private_msg(int(a[2]), a[3]), ensure_ascii=False))
    elif cmd == "sessions":
        print(json.dumps(get_sessions(), ensure_ascii=False))
    elif cmd == "msgs":
        print(json.dumps(fetch_session_msgs(int(a[2])), ensure_ascii=False))
    elif cmd == "delete_comment":
        print(json.dumps(delete_comment(int(a[2]), int(a[3])), ensure_ascii=False))
    elif cmd == "reply":
        aid = int(a[2]); root = int(a[3]); parent = int(a[4]); msg = a[5]
        at_uid = int(a[6]) if len(a) > 6 else 0
        at_name = a[7] if len(a) > 7 else ""
        print(json.dumps(reply_comment(aid, msg, root, parent, at_uid, at_name), ensure_ascii=False))
    elif cmd == "upload":
        print(json.dumps(submit_video(a[2], a[3], int(a[4]), a[5],
              a[6] if len(a) > 6 else ""), ensure_ascii=False))
    elif cmd == "archive_pre":
        print(json.dumps(archive_pre(), ensure_ascii=False))
    elif cmd == "upload_part":
        print(json.dumps(upload_video(a[2]), ensure_ascii=False))
    elif cmd == "submit":
        print(json.dumps(submit_archive(a[2], int(a[3]), a[4], a[5], a[6],
              a[7] if len(a) > 7 else "", int(a[8]) if len(a) > 8 else 1,
              a[9] if len(a) > 9 else ""), ensure_ascii=False))
    elif cmd == "cover":
        print(json.dumps(cover_up(a[2]), ensure_ascii=False))
    else:
        print("cmds: login(扫码登录,凭据存插件目录) | archives | comments <aid> | stat <bvid> | search <kw> [order] | danmaku <bvid> | danmaku_send <bvid> <text> [ms] | like <bvid> | coin <bvid> [n] | favorite <bvid> | follow <mid> | dynamic <text> | pm <uid> <text> | delete_comment <aid> <rpid> | reply <aid> <root> <parent> <msg> [atUid] [atName] | upload <file> <title> <tid> <tag> [desc]")
