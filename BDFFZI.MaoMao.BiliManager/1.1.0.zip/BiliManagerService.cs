using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Alife.Foundation;
using Alife.Framework;
using Alife.Function.FunctionCaller;
using Microsoft.Extensions.Logging;

namespace BDFFZI.MaoMao.BiliManager;

public class BiliManagerConfig
{
    [Description("运行python脚本用的解释器路径（留空则自动探测）")]
    public string PythonExe { get; set; } = "";
}

[Module("B站管理",
    "管理B站账号：查看稿件与数据、读取和回复评论、投稿视频等，让AI自己当UP主。",
    defaultCategory: "真央的小工具")]
public class BiliManagerService(
    XmlFunctionCaller functionCaller,
    ILogger<BiliManagerService> logger,
    Interactor<BiliManagerService> interactor) :
    ChatBehaviour,
    IConfigurable<BiliManagerConfig>
{
    public BiliManagerConfig Configuration { get; set; } = null!;

    string ScriptPath => Path.Combine(AlifePath.StorageFolderPath, "Plugins", "BDFFZI.MaoMao.BiliManager", "bili_manager.py");

    string PythonExe
    {
        get
        {
            if (!string.IsNullOrWhiteSpace(Configuration.PythonExe) && File.Exists(Configuration.PythonExe))
                return Configuration.PythonExe;
            string p = Path.Combine(AlifePath.RuntimeFolderPath, "Python312", "python.exe");
            return File.Exists(p) ? p : "python";
        }
    }

    async Task<string> RunAsync(params string[] args)
    {
        var psi = new ProcessStartInfo
        {
            FileName = PythonExe,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8,
        };
        psi.ArgumentList.Add("-u");
        psi.ArgumentList.Add(ScriptPath);
        foreach (string a in args)
            psi.ArgumentList.Add(a);

        using var proc = new Process { StartInfo = psi };
        var sbErr = new StringBuilder();
        proc.ErrorDataReceived += (_, e) => { if (e.Data != null) sbErr.AppendLine(e.Data); };
        proc.Start();
        proc.BeginErrorReadLine();
        string output = await proc.StandardOutput.ReadToEndAsync();
        await proc.WaitForExitAsync();
        if (proc.ExitCode != 0)
            throw new Exception($"B站脚本执行失败({proc.ExitCode}): {sbErr}");
        return output.Trim();
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("查询当前B站账号的稿件列表（含标题、播放、点赞、评论数）")]
    public async Task Archives()
    {
        string json = await RunAsync("archives");
        interactor.Poke("B站稿件列表：\n" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("查询指定视频的数据（播放、点赞、投币、收藏、评论、弹幕等）。bvid 形如 BV1xx411x7xx")]
    public async Task VideoStat([Description("视频的bvid")] string bvid)
    {
        string json = await RunAsync("stat", bvid);
        interactor.Poke("视频数据：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("读取指定视频的评论区。aid 是视频的数字id（可用 VideoStat 获取）")]
    public async Task Comments(
        [Description("视频的aid数字id")] long aid,
        [Description("页码，默认1")] int pn = 1)
    {
        string json = await RunAsync("comments", aid.ToString(), pn.ToString());
        interactor.Poke("视频评论：\n" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("在指定视频下发一条评论，或回复某条评论（回复时填 root 和 parent，均为被回复评论的 rpid）。此操作会真实发布，请先确认内容")]
    public async Task ReplyComment(
        [Description("视频的aid数字id")] long aid,
        [Description("评论正文")] string message,
        [Description("顶级评论rpid，回复某条评论时填，普通发评论填0")] long root = 0,
        [Description("被回复评论rpid，回复某条评论时填，普通发评论填0")] long parent = 0)
    {
        string json = await RunAsync("reply", aid.ToString(), root.ToString(), parent.ToString(), message);
        interactor.Poke("评论结果：" + json);
    }


    [XmlFunction(FunctionMode.OneShot)]
    [Description("投递/发布一个视频到B站。此操作会真实公开投稿，务必先获得主人确认再调用。(未实机验证过，首次使用请谨慎)")]
    public async Task UploadVideo(
        [Description("本地视频文件绝对路径")] string file,
        [Description("视频标题")] string title,
        [Description("分区tid，如171=电子竞技,21=日常,138=搞笑")] int tid,
        [Description("标签，多个用逗号分隔")] string tag,
        [Description("视频简介，可选")] string desc = "")
    {
        string json = await RunAsync("upload", file, title, tid.ToString(), tag, desc);
        interactor.Poke("投稿结果：" + json);
    }

    protected override Task OnAwake()
    {
        var handler = new XmlHandler(this)
        {
            Description = "此服务可以管理B站账号：查询稿件和数据、读取评论区、发评论或回复评论。"
        };
        functionCaller.RegisterHandler(handler, DocumentMode.Implicit, cancellationToken: DestroyCancellationToken);
        return Task.CompletedTask;
    }

    protected override Task OnDestroy() => Task.CompletedTask;
}
