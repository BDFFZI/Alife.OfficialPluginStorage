# -*- coding: utf-8 -*-
"""B站视频上传模块（upos 分片上传）· 真央 2026-10-08
依据 biliup-rs crates/biliup/src/uploader/line/upos.rs 实现
用法: python bili_upload.py <视频路径>
成功返回 JSON: {"ok":1,"filename":<location>,"biz_id":..}
"""
import sys, os, json, math, requests

BASE = r"C:\Users\13309\Documents\Alife\Storage"
ACC = os.path.join(BASE, "bili_account.json")

def _cookie(acc):
    return f"SESSDATA={acc['SESSDATA']}; bili_jct={acc['bili_jct']}; DedeUserID={acc['mid']}"

def upload_video(path, fname=None, profile="ugcupos/bup"):
    acc = json.load(open(ACC, encoding="utf-8"))
    UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120"
    fname = fname or os.path.basename(path)
    total = os.path.getsize(path)
    s = requests.Session()
    s.headers.update({"User-Agent": UA, "Referer": "https://member.bilibili.com/", "Cookie": _cookie(acc)})
    pu = s.get(f"https://member.bilibili.com/preupload?name={fname}&size={total}&r=upos&profile={profile}&ssl=0&version=2.14.0&build=2140000").json()
    upos_uri = pu["upos_uri"].replace("upos://", "")
    endpoint = "https:" + pu["endpoint"]
    auth = pu["auth"]; biz = pu["biz_id"]; chunk_size = pu["chunk_size"]
    url = f"{endpoint}/{upos_uri}"
    r = s.post(f"{url}?uploads&output=json", headers={"X-Upos-Auth": auth}, timeout=60)
    upload_id = r.json()["upload_id"]
    chunks = math.ceil(total / chunk_size); parts = []
    with open(path, "rb") as f:
        for i in range(chunks):
            data = f.read(chunk_size); start = i * chunk_size; end = start + len(data)
            params = dict(uploadId=upload_id, chunks=chunks, total=total, chunk=i,
                          size=len(data), partNumber=i + 1, start=start, end=end)
            r = s.put(url, params=params, headers={"X-Upos-Auth": auth, "Content-Length": str(len(data))}, data=data, timeout=300)
            if r.status_code == 200:
                parts.append({"partNumber": i + 1, "eTag": "etag"})
    comp = {"name": fname, "uploadId": upload_id, "biz_id": biz, "output": "json", "profile": profile}
    r = s.post(url, params=comp, headers={"X-Upos-Auth": auth}, json={"parts": parts}, timeout=60)
    res = r.json()
    return {"ok": res.get("OK"), "filename": res.get("key", "").lstrip("/"), "location": res.get("location"), "biz_id": biz}

if __name__ == "__main__":
    p = sys.argv[1]
    print(json.dumps(upload_video(p), ensure_ascii=False))


def submit_video(videos, title, tid=171, tag="", desc="", cover="", copyright=1, source="", dynamic=""):
    """提交稿件。videos: [{"filename": <上传得到的filename>, "title":.., "desc":..}]
    返回B站接口原始JSON（code=0成功）
    """
    acc = json.load(open(ACC, encoding="utf-8"))
    jct = acc["bili_jct"]
    UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120"
    s = requests.Session()
    s.headers.update({"User-Agent": UA, "Referer": "https://member.bilibili.com/", "Cookie": _cookie(acc)})
    api = f"https://member.bilibili.com/x/vu/web/add?csrf={jct}"
    post = {
        "copyright": copyright, "source": source, "tid": tid, "cover": cover,
        "title": title, "desc_format_id": 0, "desc": desc, "dynamic": dynamic,
        "tag": tag, "videos": videos, "dtime": None, "interactive": 0, "act_reserve_create": 0,
        "no_disturbance": 0, "no_reprint": 1, "open_elec": 1, "subtitle": {"open": 0, "lan": ""},
    }
    return s.post(api, json=post, timeout=30).json()
