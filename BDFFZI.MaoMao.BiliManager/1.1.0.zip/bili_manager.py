# -*- coding: utf-8 -*-
"""B站管理脚本：查询稿件/评论/数据/投稿/回复评论。凭证读 Storage\bili_account.json"""
import json, os, sys, urllib.request, urllib.parse, time, hashlib
sys.stdout.reconfigure(encoding='utf-8')

BASE = r"C:\Users\13309\Documents\Alife\Storage"
_acc = json.load(open(os.path.join(BASE, "bili_account.json"), encoding="utf-8"))
SESSDATA, JCT, UID = _acc["SESSDATA"], _acc["bili_jct"], _acc["mid"]
COOKIE = f"SESSDATA={SESSDATA}; bili_jct={JCT}; DedeUserID={UID}"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"

def req(url, data=None, method=None):
    body = urllib.parse.urlencode(data).encode() if isinstance(data, dict) else data
    r = urllib.request.Request(url, data=body, method=method, headers={
        "User-Agent": UA, "Referer": "https://www.bilibili.com/", "Cookie": COOKIE,
        "Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(r, timeout=20) as resp:
        return json.loads(resp.read().decode("utf-8"))

def get_archives(pn=1, ps=20):
    d = req(f"https://member.bilibili.com/x/web/archives?status=is_pubing,pubed,not_pubed&pn={pn}&ps={ps}")
    out = []
    for a in (d.get("data", {}).get("arc_audits") or []):
        arc = a.get("Archive", {})
        out.append({"bvid": arc.get("bvid"), "aid": arc.get("aid"), "title": arc.get("title"),
                    "state": arc.get("state_desc") or arc.get("state"),
                    "play": (a.get("stat") or {}).get("view"),
                    "like": (a.get("stat") or {}).get("like"),
                    "comment": (a.get("stat") or {}).get("reply")})
    return {"code": d.get("code"), "count": d.get("data", {}).get("page", {}).get("count"), "list": out}

def get_comments(aid, pn=1, ps=20, sort=2):
    d = req(f"https://api.bilibili.com/x/v2/reply?type=1&oid={aid}&sort={sort}&pn={pn}&ps={ps}")
    out = []
    for c in (d.get("data", {}).get("replies") or []):
        m = c.get("member", {})
        out.append({"rpid": c.get("rpid"), "user": m.get("uname"), "uid": m.get("mid"),
                    "content": c.get("content", {}).get("message"), "like": c.get("like"),
                    "root": c.get("root"), "parent": c.get("parent")})
    return {"code": d.get("code"), "count": d.get("data", {}).get("page", {}).get("count") if d.get("data") else 0, "list": out}

def reply_comment(aid, message, root=0, parent=0):
    """回复某视频评论。root=顶级评论rpid，parent=被回复评论rpid。发新评论 root=0,parent=0"""
    return req("https://api.bilibili.com/x/v2/reply/add",
               {"type": 1, "oid": aid, "message": message, "root": root, "parent": parent,
                "csrf": JCT})

def get_video_stat(bvid):
    d = req(f"https://api.bilibili.com/x/web-interface/view?bvid={bvid}")
    s = d.get("data", {}).get("stat", {})
    return {"code": d.get("code"), "title": d.get("data", {}).get("title"),
            "aid": d.get("data", {}).get("aid"),
            "view": s.get("view"), "like": s.get("like"), "coin": s.get("coin"),
            "favorite": s.get("favorite"), "reply": s.get("reply"), "danmaku": s.get("danmaku"),
            "share": s.get("share"), "desc": d.get("data", {}).get("desc")}



# ---------- 投稿（upos 分片上传 + 提交）依据 biliup-rs upos.rs ----------
def _upos_req(url, method="GET", headers=None, data=None):
    h = {"User-Agent": UA, "Referer": "https://member.bilibili.com/", "Cookie": COOKIE}
    if headers: h.update(headers)
    r = urllib.request.Request(url, data=data, method=method, headers=h)
    with urllib.request.urlopen(r, timeout=120) as resp:
        return resp.read().decode("utf-8")

def submit_video(file_path, title, tid, tag, desc="", cover="", copyright=1):
    """投稿视频。file_path=视频路径, tid=分区号, tag=标签(逗号分隔)"""
    import math
    size = os.path.getsize(file_path)
    fname = os.path.basename(file_path)
    # 1. preupload（profile 必须是 ugcupos/bup）
    pu = req(f"https://member.bilibili.com/preupload?name={urllib.parse.quote(fname)}&size={size}"
             f"&r=upos&profile=ugcupos/bup&ssl=0&version=2.14.0&build=2140000")
    if pu.get("OK") != 1:
        raise Exception("preupload失败: " + json.dumps(pu, ensure_ascii=False)[:300])
    upos_uri = pu["upos_uri"].replace("upos://", "")
    endpoint = "https:" + pu["endpoint"]
    auth = pu["auth"]
    biz_id = pu["biz_id"]
    chunk_size = pu.get("chunk_size", 10485760)
    url = f"{endpoint}/{upos_uri}"
    # 2. init 拿 upload_id
    init = json.loads(_upos_req(f"{url}?uploads&output=json", method="POST", headers={"X-Upos-Auth": auth}))
    upload_id = init.get("upload_id")
    if not upload_id:
        raise Exception("init失败: " + json.dumps(init, ensure_ascii=False)[:300])
    # 3. 分片 PUT
    chunks = math.ceil(size / chunk_size)
    parts = []
    with open(file_path, "rb") as f:
        for i in range(chunks):
            data = f.read(chunk_size)
            start = i * chunk_size; end = start + len(data)
            q = (f"uploadId={upload_id}&chunks={chunks}&total={size}&chunk={i}"
                 f"&size={len(data)}&partNumber={i+1}&start={start}&end={end}")
            code = _upos_req(f"{url}?{q}", method="PUT",
                             headers={"X-Upos-Auth": auth, "Content-Type": "application/octet-stream"}, data=data)
            if "MULTIPART_PUT_SUCCESS" in code or code.strip() == "":
                parts.append({"partNumber": i + 1, "eTag": "etag"})
    # 4. complete 合并
    cq = (f"name={urllib.parse.quote(fname)}&uploadId={upload_id}&biz_id={biz_id}"
          f"&output=json&profile=ugcupos/bup")
    comp = json.loads(_upos_req(f"{url}?{cq}", method="POST",
                                headers={"X-Upos-Auth": auth, "Content-Type": "application/json"},
                                data=json.dumps({"parts": parts}).encode()))
    if comp.get("OK") != 1:
        raise Exception("合并失败: " + json.dumps(comp, ensure_ascii=False)[:300])
    # 5. 提交稿件（filename 取 upos_uri 的 file_stem，不是原文件名！upos.rs 实锤）
    _stem = os.path.splitext(os.path.basename(upos_uri.split("?")[0]))[0]
    payload = {
        "copyright": copyright, "source": "", "tid": tid, "cover": cover,
        "title": title, "desc_format_id": 0, "desc": desc, "dynamic": "",
        "tag": tag, "videos": [{"filename": _stem, "title": title, "desc": ""}],
        "dtime": None, "interactive": 0, "act_reserve_create": 0,
        "no_disturbance": 0, "no_reprint": 1, "open_elec": 1,
        "subtitle": {"open": 0, "lan": ""},
    }
    return _add_archive(payload)

def _add_archive(payload):
    body = json.dumps(payload).encode()
    r = urllib.request.Request("https://member.bilibili.com/x/vu/web/add?csrf=" + JCT, data=body,
                  headers={"User-Agent": UA, "Referer": "https://member.bilibili.com/",
                           "Cookie": COOKIE, "Content-Type": "application/json"})
    with urllib.request.urlopen(r, timeout=60) as resp:
        return json.loads(resp.read().decode())

def _add_archive(payload):
    import urllib.request as u
    body = json.dumps(payload).encode()
    r = u.Request("https://member.bilibili.com/x/vu/web/add?csrf=" + JCT, data=body,
                  headers={"User-Agent": UA, "Referer": "https://member.bilibili.com/",
                           "Cookie": COOKIE, "Content-Type": "application/json"})
    with u.urlopen(r, timeout=60) as resp:
        return json.loads(resp.read().decode())

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "help"
    if cmd == "archives":
        print(json.dumps(get_archives(), ensure_ascii=False))
    elif cmd == "comments":
        print(json.dumps(get_comments(int(sys.argv[2])), ensure_ascii=False))
    elif cmd == "stat":
        print(json.dumps(get_video_stat(sys.argv[2]), ensure_ascii=False))
    elif cmd == "reply":
        aid = int(sys.argv[2]); root = int(sys.argv[3]); parent = int(sys.argv[4]); msg = sys.argv[5]
        print(json.dumps(reply_comment(aid, msg, root, parent), ensure_ascii=False))
    elif cmd == "upload":
        # upload <file> <title> <tid> <tag> [desc]
        print(json.dumps(submit_video(sys.argv[2], sys.argv[3], int(sys.argv[4]), sys.argv[5],
              sys.argv[6] if len(sys.argv) > 6 else ""), ensure_ascii=False))
    else:
        print("cmds: archives | comments <aid> | stat <bvid> | reply <aid> <root> <parent> <msg> | upload <file> <title> <tid> <tag> [desc]")
