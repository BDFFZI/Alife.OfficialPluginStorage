using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Alife.Foundation;
using Alife.Framework;
using Alife.Function.FunctionCaller;
using Microsoft.Extensions.Logging;

namespace BDFFZI.MaoMao.BiliManager;

public class BiliManagerConfig
{
    [Description("运行python脚本用的解释器路径（留空则自动探测）")]
    public string PythonExe { get; set; } = "";
}

[Module("B站管理",
    "管理B站账号：查看稿件与数据、搜索视频、读取评论弹幕、发评论/弹幕/动态/私信、点赞投币收藏关注、投稿视频等，让AI自己当UP主。",
    defaultCategory: "真央的小工具")]
public class BiliManagerService(
    XmlFunctionCaller functionCaller,
    ILogger<BiliManagerService> logger,
    Interactor<BiliManagerService> interactor) :
    ChatBehaviour,
    IConfigurable<BiliManagerConfig>
{
    public BiliManagerConfig Configuration { get; set; } = null!;

    string ScriptPath => Path.Combine(AlifePath.StorageFolderPath, "Plugins", "BDFFZI.MaoMao.BiliManager", "bili_manager.py");

    string PythonExe
    {
        get
        {
            if (!string.IsNullOrWhiteSpace(Configuration.PythonExe) && File.Exists(Configuration.PythonExe))
                return Configuration.PythonExe;
            string p = Path.Combine(AlifePath.RuntimeFolderPath, "Python312", "python.exe");
            return File.Exists(p) ? p : "python";
        }
    }

    async Task<string> RunAsync(params string[] args)
    {
        var psi = new ProcessStartInfo
        {
            FileName = PythonExe,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8,
        };
        psi.ArgumentList.Add("-u");
        psi.ArgumentList.Add(ScriptPath);
        foreach (string a in args)
            psi.ArgumentList.Add(a);

        using var proc = new Process { StartInfo = psi };
        var sbErr = new StringBuilder();
        proc.ErrorDataReceived += (_, e) => { if (e.Data != null) sbErr.AppendLine(e.Data); };
        proc.Start();
        proc.BeginErrorReadLine();
        string output = await proc.StandardOutput.ReadToEndAsync();
        await proc.WaitForExitAsync();
        if (proc.ExitCode != 0)
            throw new Exception($"B站脚本执行失败({proc.ExitCode}): {sbErr}");
        return output.Trim();
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("查询当前B站账号的稿件列表（含标题、播放、点赞、评论数）")]
    public async Task Archives()
    {
        string json = await RunAsync("archives");
        interactor.Poke("B站稿件列表：\n" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("查询指定视频的数据（aid、cid、播放、点赞、投币、收藏、评论、弹幕、分享等）。bvid 形如 BV1xx411x7xx")]
    public async Task VideoStat([Description("视频的bvid")] string bvid)
    {
        string json = await RunAsync("stat", bvid);
        interactor.Poke("视频数据：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("搜索B站视频（返回标题、bvid、UP主、播放量、时长、发布时间）")]
    public async Task SearchVideos(
        [Description("搜索关键词")] string keyword,
        [Description("排序：totalrank综合/pubdate最新/click播放/stow收藏，默认totalrank")] string order = "totalrank")
    {
        string json = await RunAsync("search", keyword, order);
        interactor.Poke("搜索结果：\n" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("读取指定视频的弹幕节选（时间+内容）")]
    public async Task Danmaku(
        [Description("视频的bvid")] string bvid,
        [Description("最多返回几条，默认60")] int limit = 60)
    {
        string json = await RunAsync("danmaku", bvid);
        interactor.Poke("弹幕节选：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("下载指定视频并均匀抽帧拼成带帧号的网格图，返回图片路径，用LoadImage查看后即可亲自看视频内容。首次使用会自动下载ffmpeg（多镜像），需耐心等待")]
    public async Task Frames(
        [Description("视频的bvid")] string bvid,
        [Description("抽帧数，4~24，默认12")] int count = 12)
    {
        string json = await RunAsync("frames", bvid, count.ToString());
        interactor.Poke("抽帧结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("发送一条弹幕到指定视频。此操作会真实发布，请谨慎")]
    public async Task SendDanmaku(
        [Description("视频的bvid")] string bvid,
        [Description("弹幕内容")] string text,
        [Description("发送位置（毫秒），默认0=开头")] int progressMs = 0)
    {
        string json = await RunAsync("danmaku_send", bvid, text, progressMs.ToString());
        interactor.Poke("弹幕发送结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("读取指定视频的评论区。aid 是视频的数字id（可用 VideoStat 获取）")]
    public async Task Comments(
        [Description("视频的aid数字id")] long aid,
        [Description("页码，默认1")] int pn = 1)
    {
        string json = await RunAsync("comments", aid.ToString(), pn.ToString());
        interactor.Poke("视频评论：\n" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("在指定视频下发一条评论，或回复某条评论（回复时填 root 和 parent，均为被回复评论的 rpid）。可带真@：填 atUid 和 atName（message 中需含 @atName 字样加空格）。此操作会真实发布，请谨慎")]
    public async Task ReplyComment(
        [Description("视频的aid数字id")] long aid,
        [Description("评论正文")] string message,
        [Description("顶级评论rpid，回复某条评论时填，普通发评论填0")] long root = 0,
        [Description("被回复评论rpid，回复某条评论时填，普通发评论填0")] long parent = 0,
        [Description("要@的用户uid，可选")] long atUid = 0,
        [Description("要@的用户昵称，需与atUid配套")] string atName = "")
    {
        string json = await RunAsync("reply", aid.ToString(), root.ToString(), parent.ToString(), message,
            atUid.ToString(), atName);
        interactor.Poke("评论结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("删除自己发出的评论。aid是视频数字id，rpid是评论id")]
    public async Task DeleteComment(
        [Description("视频的aid数字id")] long aid,
        [Description("要删除的评论rpid")] long rpid)
    {
        string json = await RunAsync("delete_comment", aid.ToString(), rpid.ToString());
        interactor.Poke("删除结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("给视频点赞（再次调用取消赞）。此操作会真实生效")]
    public async Task Like([Description("视频的bvid")] string bvid)
    {
        string json = await RunAsync("like", bvid);
        interactor.Poke("点赞结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("给视频投币（1或2个）。此操作会真实消耗硬币")]
    public async Task Coin(
        [Description("视频的bvid")] string bvid,
        [Description("投几个币，1或2，默认1")] int multiply = 1)
    {
        string json = await RunAsync("coin", bvid, multiply.ToString());
        interactor.Poke("投币结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("收藏视频到默认收藏夹。此操作会真实生效")]
    public async Task Favorite([Description("视频的bvid")] string bvid)
    {
        string json = await RunAsync("favorite", bvid);
        interactor.Poke("收藏结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("关注/取关用户（act=1关注，2拉黑，需谨慎）")]
    public async Task Follow(
        [Description("目标用户的mid")] long mid,
        [Description("动作：1关注，默认1")] int act = 1)
    {
        string json = await RunAsync("follow", mid.ToString(), act.ToString());
        interactor.Poke("关注结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("发布一条纯文字B站动态。此操作会真实发布，请谨慎")]
    public async Task PostDynamic([Description("动态正文")] string text)
    {
        string json = await RunAsync("dynamic", text);
        interactor.Poke("动态发布结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("给B站用户发一条私信。此操作会真实发送，请谨慎，内容不得包含隐私")]
    public async Task SendPrivateMsg(
        [Description("目标用户的mid")] long uid,
        [Description("私信内容")] string text)
    {
        string json = await RunAsync("pm", uid.ToString(), text);
        interactor.Poke("私信结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("投递/发布一个视频到B站。此操作会真实公开投稿，务必先获得主人确认再调用。(未实机验证过，首次使用请谨慎)")]
    public async Task UploadVideo(
        [Description("本地视频文件绝对路径")] string file,
        [Description("视频标题")] string title,
        [Description("分区tid，如171=电子竞技,21=日常,138=搞笑")] int tid,
        [Description("标签，多个用逗号分隔")] string tag,
        [Description("视频简介，可选")] string desc = "")
    {
        string json = await RunAsync("upload", file, title, tid.ToString(), tag, desc);
        interactor.Poke("投稿结果：" + json);
    }

    protected override Task OnAwake()
    {
        var handler = new XmlHandler(this)
        {
            Description = "此服务可以管理B站账号：查询稿件和数据、搜索视频、读取评论弹幕、发评论/弹幕/动态/私信、点赞投币收藏关注、投稿视频。"
        };
        functionCaller.RegisterHandler(handler, DocumentMode.Implicit, cancellationToken: DestroyCancellationToken);
        return Task.CompletedTask;
    }

    protected override Task OnDestroy() => Task.CompletedTask;
}
