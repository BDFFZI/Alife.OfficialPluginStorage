# -*- coding: utf-8 -*-
"""B站管理脚本：账号/稿件/评论/数据/投稿/搜索/弹幕/点赞/收藏/投币/关注/发弹幕/动态/私信/删评。凭证读 Storage\bili_account.json"""
import json, os, sys, urllib.request, urllib.parse, time, hashlib, re
sys.stdout.reconfigure(encoding='utf-8')

# Storage目录从脚本位置动态推导：脚本在 Storage\Plugins\插件名\ 下，上两级即Storage
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_acc_path = os.path.join(BASE, "bili_account.json")
if os.path.exists(_acc_path):
    _acc = json.load(open(_acc_path, encoding="utf-8"))
    SESSDATA, JCT, UID = _acc["SESSDATA"], _acc["bili_jct"], _acc["mid"]
    COOKIE = f"SESSDATA={SESSDATA}; bili_jct={JCT}; DedeUserID={UID}"
else:
    SESSDATA, JCT, UID = "", "", 0
    COOKIE = ""

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"

def req(url, data=None, method=None, json_body=None):
    if json_body is not None:
        body = json.dumps(json_body).encode()
        ct = "application/json"
    else:
        body = urllib.parse.urlencode(data).encode() if isinstance(data, dict) else data
        ct = "application/x-www-form-urlencoded"
    r = urllib.request.Request(url, data=body, method=method, headers={
        "User-Agent": UA, "Referer": "https://www.bilibili.com/", "Cookie": COOKIE,
        "Content-Type": ct})
    with urllib.request.urlopen(r, timeout=20) as resp:
        return json.loads(resp.read().decode("utf-8"))

# ---------- 原有能力 ----------
def get_archives(pn=1, ps=20):
    d = req(f"https://member.bilibili.com/x/web/archives?status=is_pubing,pubed,not_pubed&pn={pn}&ps={ps}")
    out = []
    for a in (d.get("data", {}).get("arc_audits") or []):
        arc = a.get("Archive", {})
        out.append({"bvid": arc.get("bvid"), "aid": arc.get("aid"), "title": arc.get("title"),
                    "state": arc.get("state_desc") or arc.get("state"),
                    "play": (a.get("stat") or {}).get("view"),
                    "like": (a.get("stat") or {}).get("like"),
                    "comment": (a.get("stat") or {}).get("reply")})
    return {"code": d.get("code"), "count": d.get("data", {}).get("page", {}).get("count"), "list": out}

def get_comments(aid, pn=1, ps=20, sort=2):
    d = req(f"https://api.bilibili.com/x/v2/reply?type=1&oid={aid}&sort={sort}&pn={pn}&ps={ps}")
    out = []
    for c in (d.get("data", {}).get("replies") or []):
        m = c.get("member", {})
        out.append({"rpid": c.get("rpid"), "user": m.get("uname"), "uid": m.get("mid"),
                    "content": c.get("content", {}).get("message"), "like": c.get("like"),
                    "root": c.get("root"), "parent": c.get("parent")})
    return {"code": d.get("code"), "count": d.get("data", {}).get("page", {}).get("count") if d.get("data") else 0, "list": out}

def reply_comment(aid, message, root=0, parent=0, at_uid=0, at_name=""):
    """发评论/回复。at_uid+at_name实现真@（message需含"@名字 "字样）"""
    form = {"type": 1, "oid": aid, "message": message, "root": root, "parent": parent, "csrf": JCT}
    if at_uid:
        form["at_uids"] = str(at_uid)
        form["at_name_to_mid"] = json.dumps({f"@{at_name} ": str(at_uid)})
    return req("https://api.bilibili.com/x/v2/reply/add", form)

def delete_comment(aid, rpid):
    return req("https://api.bilibili.com/x/v2/reply/del", {"type": 1, "oid": aid, "rpid": rpid, "csrf": JCT})

def get_video_stat(bvid):
    d = req(f"https://api.bilibili.com/x/web-interface/view?bvid={bvid}")
    data = d.get("data") or {}
    s = data.get("stat", {})
    return {"code": d.get("code"), "title": data.get("title"), "aid": data.get("aid"),
            "cid": data.get("cid"), "view": s.get("view"), "like": s.get("like"),
            "coin": s.get("coin"), "favorite": s.get("favorite"), "reply": s.get("reply"),
            "danmaku": s.get("danmaku"), "share": s.get("share"), "desc": data.get("desc")}

# ---------- 新增：搜索 ----------
def _req_nocookie(url):
    r = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": "https://www.bilibili.com/"})
    with urllib.request.urlopen(r, timeout=20) as resp:
        return json.loads(resp.read().decode("utf-8"))

def search_videos(keyword, pn=1, order="totalrank"):
    kw = urllib.parse.quote(keyword)
    url = f"https://api.bilibili.com/x/web-interface/search/type?search_type=video&keyword={kw}&order={order}&page={pn}"
    try:
        d = _req_nocookie(url)  # 搜索接口带cookie易触发412风控，优先无cookie
    except Exception:
        d = req(url)
    out = []
    for v in ((d.get("data") or {}).get("result") or [])[:20]:
        t = v.get("title", "")
        t = re.sub(r"</?em[^>]*>", "", t)
        out.append({"bvid": v.get("bvid"), "title": t, "author": v.get("author"),
                    "play": v.get("play"), "danmaku": v.get("video_review"),
                    "duration": v.get("duration"), "pubdate": v.get("pubdate")})
    return {"code": d.get("code"), "numResults": (d.get("data") or {}).get("numResults"), "list": out}

# ---------- 新增：弹幕 ----------
def get_danmaku(bvid, limit=60):
    import gzip
    d = get_video_stat(bvid)
    if d.get("code") != 0:
        return d
    cid = d.get("cid")
    r = urllib.request.Request(f"https://comment.bilibili.com/{cid}.xml",
                               headers={"User-Agent": UA, "Referer": "https://www.bilibili.com/"})
    with urllib.request.urlopen(r, timeout=20) as resp:
        raw = resp.read()
    import zlib
    if raw[:2] == b"\x1f\x8b":
        raw = gzip.decompress(raw)
    else:
        try:
            raw = zlib.decompress(raw, -15)
        except Exception:
            pass
    xml = raw.decode("utf-8", "ignore")
    items = re.findall(r'<d p="([^"]+)">([^<]+)</d>', xml)
    out = [{"t": float(p.split(",")[0]), "text": x} for p, x in items[:limit]]
    return {"code": 0, "bvid": bvid, "list": out}

def send_danmaku(bvid, text, progress_ms=0):
    d = get_video_stat(bvid)
    aid, cid = d.get("aid"), d.get("cid")
    return req("https://api.bilibili.com/x/v2/dm/post/send",
               {"type": 1, "oid": cid, "msg": text, "bvid": bvid, "progress": int(progress_ms),
                "rnd": int(time.time() * 1000) % 100000000000, "csrf": JCT, "csrf_token": JCT})

# ---------- 新增：点赞/投币/收藏/关注 ----------
def like(bvid, is_like=1):
    """is_like: 1点赞 2取消。取消需要先拿aid再传like=2"""
    d = get_video_stat(bvid)
    return req("https://api.bilibili.com/x/web-interface/archive/like",
               {"aid": d.get("aid"), "like": is_like, "csrf": JCT, "csrf_token": JCT})

def coin_add(bvid, multiply=1, with_like=1):
    d = get_video_stat(bvid)
    return req("https://api.bilibili.com/x/web-interface/coin/add",
               {"aid": d.get("aid"), "multiply": multiply, "select_like": with_like,
                "csrf": JCT, "csrf_token": JCT})

def favorite(bvid):
    d = get_video_stat(bvid)
    fl = req("https://api.bilibili.com/x/v3/fav/folder/created/list-all?up_mid=" + str(UID))
    mlist = ((fl.get("data") or {}).get("list") or [])
    if not mlist:
        return {"error": "没有可用收藏夹"}
    fid = mlist[0]["id"]
    return req("https://api.bilibili.com/x/v3/fav/resource/deal",
               {"rid": d.get("aid"), "type": 2, "fid": fid, "csrf": JCT, "csrf_token": JCT})

def follow(mid_num, act=1):
    return req("https://api.bilibili.com/x/relation/modify",
               {"fid": mid_num, "act": act, "re_src": 11, "csrf": JCT, "csrf_token": JCT})

# ---------- 新增：动态/私信 ----------
def post_dynamic(text):
    payload = {"dyn_req": {"content": [{"dyn_type": 1, "text_contents": [
        {"nodes": [{"type": "TEXT", "rid": -1, "text": text}]}]}]}}
    return req("https://api.bilibili.com/x/dynamic/feed/dyn/send?csrf=" + JCT, json_body=payload)

def send_private_msg(receiver_uid, text):
    return req("https://api.bilibili.com/x/web-im/v1/web/im/send_msg",
               {"msg[sender_id]": UID, "msg[receiver_id]": receiver_uid, "msg[msg_type]": 1,
                "msg[content]": text, "msg[timestamp]": int(time.time()),
                "msg[dev_id]": "Alife", "csrf": JCT, "csrf_token": JCT})

# ---------- 新增：抽帧看片 ----------
FFMPEG_PATH = os.path.join(BASE, "Tools", "ffmpeg.exe")

# 镜像清单与 presents.BiliScroll ToolsFetcher.cs 同源（zip包，已核实可用）
FFMPEG_URLS = [
    "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip",
    "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip",
    "https://gh-proxy.com/https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip",
]

def _ensure_ffmpeg():
    """确保ffmpeg可用：本地Tools有就用，常见位置/PATH兜底，都没有才按镜像逐个下载"""
    if os.path.exists(FFMPEG_PATH):
        return FFMPEG_PATH
    # 常见位置兜底（如BiliScroll装过的tools目录）
    import glob as _g
    for pat in (os.path.join(BASE, "BiliScrollTools", "ffmpeg.exe"),
                os.path.join(BASE, "Plugins", "presents.BiliScroll", "tools", "**", "ffmpeg.exe")):
        hits = _g.glob(pat, recursive=True)
        if hits:
            return hits[0]
    import subprocess as _sp
    try:
        _sp.run(["ffmpeg", "-version"], capture_output=True, timeout=15)
        return "ffmpeg"
    except Exception:
        pass
    os.makedirs(os.path.dirname(FFMPEG_PATH), exist_ok=True)
    import zipfile as _zf
    for url in FFMPEG_URLS:
        try:
            print(f"下载ffmpeg: {url}", file=sys.stderr)
            zpath = FFMPEG_PATH + ".zip.tmp"
            r = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(r, timeout=600) as resp, open(zpath, "wb") as f:
                while True:
                    chunk = resp.read(1024 * 256)
                    if not chunk:
                        break
                    f.write(chunk)
            # 解压取ffmpeg.exe（zip内可能在子目录）
            with _zf.ZipFile(zpath) as z:
                for n in z.namelist():
                    if n.lower().endswith("ffmpeg.exe"):
                        with z.open(n) as s, open(FFMPEG_PATH + ".tmp", "wb") as d:
                            while True:
                                c = s.read(1024 * 256)
                                if not c:
                                    break
                                d.write(c)
                        break
            os.remove(zpath)
            if os.path.exists(FFMPEG_PATH + ".tmp") and os.path.getsize(FFMPEG_PATH + ".tmp") > 10 * 1024 * 1024:
                os.replace(FFMPEG_PATH + ".tmp", FFMPEG_PATH)
                return FFMPEG_PATH
            raise RuntimeError("解压后未找到ffmpeg.exe")
        except Exception as e:
            print(f"镜像失败 {url}: {e}", file=sys.stderr)
            continue
    raise RuntimeError("ffmpeg下载失败，所有镜像均不可用")

def extract_frames(bvid, count=12):
    """下载视频并均匀抽帧拼成网格图，返回图片路径。count范围4~24"""
    import subprocess, glob as _glob
    count = max(4, min(24, int(count)))
    d = get_video_stat(bvid)
    if d.get("code") != 0:
        return d
    cid, dur = d.get("cid"), d.get("duration") or 120
    ff = _ensure_ffmpeg()
    out_dir = os.path.join(BASE, "Temp", f"bili_frames_{bvid}")
    os.makedirs(out_dir, exist_ok=True)
    vid = os.path.join(out_dir, "video.mp4")
    if not os.path.exists(vid) or os.path.getsize(vid) < 100000:
        # 拿播放流
        r = urllib.request.Request(
            f"https://api.bilibili.com/x/player/playurl?bvid={bvid}&cid={cid}&qn=32&fnval=0",
            headers={"User-Agent": UA, "Referer": "https://www.bilibili.com/", "Cookie": COOKIE})
        pd = json.loads(urllib.request.urlopen(r, timeout=20).read().decode())
        if pd.get("code") != 0:
            return {"code": pd.get("code"), "error": "拿播放流失败"}
        url = pd["data"]["durl"][0]["url"]
        req2 = urllib.request.Request(url, headers={
            "User-Agent": UA, "Referer": "https://www.bilibili.com/", "Cookie": COOKIE, "Range": "bytes=0-"})
        with urllib.request.urlopen(req2, timeout=180) as resp, open(vid, "wb") as f:
            f.write(resp.read())
    grid = os.path.join(out_dir, "grid.jpg")
    cols = 4 if count <= 12 else 6
    rows = 3 if count <= 12 else 4
    fps = f"{count}/{max(dur-2, 1)}"
    subprocess.run([ff, "-y", "-i", vid, "-vf", f"fps={fps},scale=480:-1,tile={cols}x{rows}",
                    "-frames:v", "1", grid], capture_output=True, timeout=180)
    if not os.path.exists(grid):
        return {"code": -1, "error": "ffmpeg抽帧失败"}
    return {"code": 0, "bvid": bvid, "title": d.get("title"), "grid": grid, "count": count}

# ---------- 投稿（原有 upos 逻辑保留） ----------
def _upos_req(url, method="GET", headers=None, data=None):
    h = {"User-Agent": UA, "Referer": "https://member.bilibili.com/", "Cookie": COOKIE}
    if headers:
        h.update(headers)
    r = urllib.request.Request(url, data=data, method=method, headers=h)
    with urllib.request.urlopen(r, timeout=120) as resp:
        return resp.read().decode("utf-8")

def _add_archive(payload):
    return req("https://member.bilibili.com/x/vu/web/add?csrf=" + JCT, json_body=payload)

def submit_video(file_path, title, tid, tag, desc="", cover="", copyright=1):
    size = os.path.getsize(file_path)
    fname = os.path.basename(file_path)
    pu = req(f"https://member.bilibili.com/preupload?name={urllib.parse.quote(fname)}&size={size}"
             f"&r=upos&profile=ugcupos/bup&ssl=0&version=2.14.0&build=2140000")
    if pu.get("OK") != 1:
        raise Exception("preupload失败: " + json.dumps(pu, ensure_ascii=False)[:300])
    upos_uri = pu["upos_uri"].replace("upos://", "")
    url = "https:" + pu["endpoint"] + "/" + upos_uri
    auth = pu["auth"]
    biz_id = pu["biz_id"]
    chunk_size = pu.get("chunk_size", 10485760)
    init = json.loads(_upos_req(f"{url}?uploads&output=json", method="POST", headers={"X-Upos-Auth": auth}))
    upload_id = init.get("upload_id")
    if not upload_id:
        raise Exception("init失败: " + json.dumps(init, ensure_ascii=False)[:300])
    chunks = (size + chunk_size - 1) // chunk_size
    parts = []
    with open(file_path, "rb") as f:
        for i in range(chunks):
            data = f.read(chunk_size)
            start = i * chunk_size
            end = start + len(data)
            q = (f"uploadId={upload_id}&chunks={chunks}&total={size}&chunk={i}"
                 f"&size={len(data)}&partNumber={i+1}&start={start}&end={end}")
            code = _upos_req(f"{url}?{q}", method="PUT",
                             headers={"X-Upos-Auth": auth, "Content-Type": "application/octet-stream"}, data=data)
            if "MULTIPART_PUT_SUCCESS" in code or code.strip() == "":
                parts.append({"partNumber": i + 1, "eTag": "etag"})
    cq = (f"name={urllib.parse.quote(fname)}&uploadId={upload_id}&biz_id={biz_id}"
          f"&output=json&profile=ugcupos/bup")
    comp = json.loads(_upos_req(f"{url}?{cq}", method="POST",
                                headers={"X-Upos-Auth": auth, "Content-Type": "application/json"},
                                data=json.dumps({"parts": parts}).encode()))
    if comp.get("OK") != 1:
        raise Exception("合并失败: " + json.dumps(comp, ensure_ascii=False)[:300])
    stem = os.path.splitext(os.path.basename(upos_uri.split("?")[0]))[0]
    payload = {
        "copyright": copyright, "source": "", "tid": tid, "cover": cover,
        "title": title, "desc_format_id": 0, "desc": desc, "dynamic": "",
        "tag": tag, "videos": [{"filename": stem, "title": title, "desc": ""}],
        "dtime": None, "interactive": 0, "act_reserve_create": 0,
        "no_disturbance": 0, "no_reprint": 1, "open_elec": 1,
        "subtitle": {"open": 0, "lan": ""},
    }
    return _add_archive(payload)

# ---------- 入口 ----------
if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "help"
    a = sys.argv
    if cmd == "archives":
        print(json.dumps(get_archives(), ensure_ascii=False))
    elif cmd == "comments":
        print(json.dumps(get_comments(int(a[2])), ensure_ascii=False))
    elif cmd == "frames":
        print(json.dumps(extract_frames(a[2], int(a[3]) if len(a) > 3 else 12), ensure_ascii=False))
    elif cmd == "stat":
        print(json.dumps(get_video_stat(a[2]), ensure_ascii=False))
    elif cmd == "search":
        kw = a[2]
        order = a[3] if len(a) > 3 else "totalrank"
        print(json.dumps(search_videos(kw, order=order), ensure_ascii=False))
    elif cmd == "danmaku":
        print(json.dumps(get_danmaku(a[2]), ensure_ascii=False))
    elif cmd == "danmaku_send":
        print(json.dumps(send_danmaku(a[2], a[3], int(a[4]) if len(a) > 4 else 0), ensure_ascii=False))
    elif cmd == "like":
        print(json.dumps(like(a[2]), ensure_ascii=False))
    elif cmd == "coin":
        print(json.dumps(coin_add(a[2], int(a[3]) if len(a) > 3 else 1), ensure_ascii=False))
    elif cmd == "favorite":
        print(json.dumps(favorite(a[2]), ensure_ascii=False))
    elif cmd == "follow":
        print(json.dumps(follow(int(a[2])), ensure_ascii=False))
    elif cmd == "dynamic":
        print(json.dumps(post_dynamic(a[2]), ensure_ascii=False))
    elif cmd == "pm":
        print(json.dumps(send_private_msg(int(a[2]), a[3]), ensure_ascii=False))
    elif cmd == "delete_comment":
        print(json.dumps(delete_comment(int(a[2]), int(a[3])), ensure_ascii=False))
    elif cmd == "reply":
        aid = int(a[2]); root = int(a[3]); parent = int(a[4]); msg = a[5]
        at_uid = int(a[6]) if len(a) > 6 else 0
        at_name = a[7] if len(a) > 7 else ""
        print(json.dumps(reply_comment(aid, msg, root, parent, at_uid, at_name), ensure_ascii=False))
    elif cmd == "upload":
        print(json.dumps(submit_video(a[2], a[3], int(a[4]), a[5],
              a[6] if len(a) > 6 else ""), ensure_ascii=False))
    else:
        print("cmds: archives | comments <aid> | stat <bvid> | search <kw> [order] | danmaku <bvid> | danmaku_send <bvid> <text> [ms] | like <bvid> | coin <bvid> [n] | favorite <bvid> | follow <mid> | dynamic <text> | pm <uid> <text> | delete_comment <aid> <rpid> | reply <aid> <root> <parent> <msg> [atUid] [atName] | upload <file> <title> <tid> <tag> [desc]")
