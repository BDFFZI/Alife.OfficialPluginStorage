using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Alife.Foundation;
using Alife.Framework;
using Alife.Function.FunctionCaller;
using Microsoft.Extensions.Logging;

namespace BDFFZI.MaoMao.BiliManager;

public class BiliManagerConfig
{
}

[Module("B站管理",
    "管理B站账号：查看稿件与数据、搜索视频、读取评论弹幕、发评论/弹幕/动态/私信、点赞投币收藏关注、投稿视频等，让AI自己当UP主。",
    defaultCategory: "真央的小工具",
    EditorUI = typeof(BiliManagerUI))]
public class BiliManagerService(
    XmlFunctionCaller functionCaller,
    ILogger<BiliManagerService> logger,
    Interactor<BiliManagerService> interactor,
    PluginSystem pluginSystem) :
    ChatBehaviour,
    IConfigurable<BiliManagerConfig>
{
    public BiliManagerConfig Configuration { get; set; } = null!;

    /// <summary>供自定义UI调用python脚本命令</summary>
    public Task<string> RunForUIAsync(params string[] args) => RunAsync(args);

    /// <summary>插件目录由框架解析，避免别处安装后目录名不同导致找不到脚本</summary>
    string PluginDir => pluginSystem.PluginContext.GetPluginDirectoryPath("BDFFZI.MaoMao.BiliManager");

    string ScriptPath => Path.Combine(PluginDir, "bili_manager.py");

    string PythonExe
    {
        get
        {
            string p = Path.Combine(AlifePath.RuntimeFolderPath, "Python312", "python.exe");
            return File.Exists(p) ? p : "python";
        }
    }

    async Task<string> RunAsync(params string[] args)
    {
        var psi = new ProcessStartInfo
        {
            FileName = PythonExe,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8,
        };
        psi.ArgumentList.Add("-u");
        psi.ArgumentList.Add(ScriptPath);
        foreach (string a in args)
            psi.ArgumentList.Add(a);

        using var proc = new Process { StartInfo = psi };
        var sbErr = new StringBuilder();
        proc.ErrorDataReceived += (_, e) => { if (e.Data != null) sbErr.AppendLine(e.Data); };
        proc.Start();
        proc.BeginErrorReadLine();
        string output = await proc.StandardOutput.ReadToEndAsync();
        await proc.WaitForExitAsync();
        if (proc.ExitCode != 0)
            throw new Exception($"B站脚本执行失败({proc.ExitCode}): {sbErr}");
        return output.Trim();
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("查询当前B站账号的稿件列表（含标题、播放、点赞、评论数）")]
    public async Task Archives()
    {
        string json = await RunAsync("archives");
        interactor.Poke("B站稿件列表：\n" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("查询指定视频的数据（aid、cid、播放、点赞、投币、收藏、评论、弹幕、分享等）。bvid 形如 BV1xx411x7xx")]
    public async Task VideoStat([Description("视频的bvid")] string bvid)
    {
        string json = await RunAsync("stat", bvid);
        interactor.Poke("视频数据：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("搜索B站视频（返回标题、bvid、UP主、播放量、时长、发布时间）")]
    public async Task SearchVideos(
        [Description("搜索关键词")] string keyword,
        [Description("排序：totalrank综合/pubdate最新/click播放/stow收藏，默认totalrank")] string order = "totalrank")
    {
        string json = await RunAsync("search", keyword, order);
        interactor.Poke("搜索结果：\n" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("读取指定视频的弹幕节选（时间+内容）")]
    public async Task Danmaku(
        [Description("视频的bvid")] string bvid,
        [Description("最多返回几条，默认60")] int limit = 60)
    {
        string json = await RunAsync("danmaku", bvid);
        interactor.Poke("弹幕节选：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("下载指定视频并均匀抽帧拼成带帧号的网格图，返回图片路径，用LoadImage查看后即可亲自看视频内容。首次使用会自动下载ffmpeg（多镜像），需耐心等待")]
    public async Task Frames(
        [Description("视频的bvid")] string bvid,
        [Description("抽帧数，4~24，默认12")] int count = 12)
    {
        string json = await RunAsync("frames", bvid, count.ToString());
        interactor.Poke("抽帧结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("查询B站投稿分区列表（返回各分区tid和名称），投稿时选tid用")]
    public async Task ArchivePre()
    {
        string json = await RunAsync("archive_pre");
        interactor.Poke("分区信息：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("上传一个本地视频文件到B站服务器暂存（不发布）。返回的bili_filename用于SubmitArchive投稿")]
    public async Task UploadVideo(
        [Description("本地视频文件绝对路径")] string filepath)
    {
        string json = await RunAsync("upload_part", filepath);
        interactor.Poke("上传结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("提交稿件正式投稿（此操作会真实发布）。filename来自UploadVideo返回的bili_filename")]
    public async Task SubmitArchive(
        [Description("稿件标题")] string title,
        [Description("分区tid，用ArchivePre查询")] int tid,
        [Description("标签，逗号分隔")] string tag,
        [Description("简介")] string desc,
        [Description("上传阶段返回的bili_filename")] string filename,
        [Description("封面url（可空）")] string cover = "",
        [Description("1自制2转载，默认1")] int copyright = 1,
        [Description("转载来源（copyright=2时填）")] string source = "")
    {
        string json = await RunAsync("submit", title, tid.ToString(), tag, desc, filename, cover,
            copyright.ToString(), source);
        interactor.Poke("投稿结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("上传封面图，返回封面url")]
    public async Task CoverUp(
        [Description("本地图片绝对路径")] string filepath)
    {
        string json = await RunAsync("cover", filepath);
        interactor.Poke("封面上传结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("发送一条弹幕到指定视频。此操作会真实发布，请谨慎")]
    public async Task SendDanmaku(
        [Description("视频的bvid")] string bvid,
        [Description("弹幕内容")] string text,
        [Description("发送位置（毫秒），默认0=开头")] int progressMs = 0)
    {
        string json = await RunAsync("danmaku_send", bvid, text, progressMs.ToString());
        interactor.Poke("弹幕发送结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("读取指定视频的评论区。aid 是视频的数字id（可用 VideoStat 获取）。每条评论带 replied 字段：true=我已在该评论下回复过（my_replies 附我回复的内容），false=没回复过。回复前先看 replied，已回复的不要再回。")]
    public async Task Comments(
        [Description("视频的aid数字id")] long aid,
        [Description("页码，默认1")] int pn = 1)
    {
        string json = await RunAsync("comments", aid.ToString(), pn.ToString());
        interactor.Poke("视频评论：\n" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("在指定视频下发一条评论，或回复某条评论（回复时填 root 和 parent，均为被回复评论的 rpid）。可带真@：填 atUid 和 atName（message 中需含 @atName 字样加空格）。此操作会真实发布。脚本内已带查重：同一评论下已有相同内容会自动阻止。")]
    public async Task ReplyComment(
        [Description("视频的aid数字id")] long aid,
        [Description("评论正文")] string message,
        [Description("顶级评论rpid，回复某条评论时填，普通发评论填0")] long root = 0,
        [Description("被回复评论rpid，回复某条评论时填，普通发评论填0")] long parent = 0,
        [Description("要@的用户uid，可选")] long atUid = 0,
        [Description("要@的用户昵称，需与atUid配套")] string atName = "",
        [Description("强制发送。默认0：若我已在同一评论下回复过，脚本直接拦截并返回我回过的内容；只有确认需要再补一句时才填1")] int forceSend = 0)
    {
        string json = await RunAsync("reply", aid.ToString(), root.ToString(), parent.ToString(), message,
            atUid.ToString(), atName, forceSend.ToString());
        interactor.Poke("评论结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("删除自己发出的评论。aid是视频数字id，rpid是评论id")]
    public async Task DeleteComment(
        [Description("视频的aid数字id")] long aid,
        [Description("要删除的评论rpid")] long rpid)
    {
        string json = await RunAsync("delete_comment", aid.ToString(), rpid.ToString());
        interactor.Poke("删除结果：" + json);
    }


    [XmlFunction(FunctionMode.OneShot)]
    [Description("查询当前登录的B站账号信息（昵称/头像/等级/硬币）。未登录时返回logged_in=false")]
    public async Task Account()
    {
        string json = await RunAsync("account");
        interactor.Poke("账号信息：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("退出当前B站账号登录（删除本地凭据）。此操作立即生效")]
    public async Task Logout()
    {
        string json = await RunAsync("logout");
        interactor.Poke("退出登录：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("B站扫码登录第一步：生成登录二维码图片，立即返回（不等待扫码）。用LoadImage查看二维码并展示给用户扫码，然后反复调用 LoginPoll 查询状态直到成功或过期")]
    public async Task Login()
    {
        string json = await RunAsync("login");
        interactor.Poke("登录：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("B站扫码登录第二步：查询扫码状态。code=0登录成功；86090已扫码待确认；86101未扫码；86038二维码过期（需重新Login）。查询间隔约2~5秒")]
    public async Task LoginPoll()
    {
        string json = await RunAsync("login_poll");
        interactor.Poke("扫码状态：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("给视频点赞。程序会先查现状：已点过赞就直接返回 code=-2 拦下，不会重复操作。若要取消点赞请用 Unlike")]
    public async Task Like([Description("视频的bvid")] string bvid)
    {
        string json = await RunAsync("like", bvid, "1");
        interactor.Poke("点赞结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("取消点赞。程序会先查现状：本来没赞就直接返回 code=-2，不会瞎操作。注意这是真取消，别拿别人的视频试")]
    public async Task Unlike([Description("视频的bvid")] string bvid)
    {
        string json = await RunAsync("like", bvid, "2");
        interactor.Poke("取消点赞结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("给视频投币（1或2个），真实消耗硬币。程序会先查已投几枚：已投过会返回 code=-2 拦下，确需追加填 force=1")]
    public async Task Coin(
        [Description("视频的bvid")] string bvid,
        [Description("投几个币，1或2，默认1")] int multiply = 1,
        [Description("强制投币。默认0：脚本发现已投过会拦下；确认要追加时才填1")] int force = 0)
    {
        string json = await RunAsync("coin", bvid, multiply.ToString(), force.ToString());
        interactor.Poke("投币结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("收藏视频到默认收藏夹。程序会先查是否已收藏过，已收藏则返回 code=-2 拦下")]
    public async Task Favorite(
        [Description("视频的bvid")] string bvid,
        [Description("强制收藏，默认0")] int force = 0)
    {
        string json = await RunAsync("favorite", bvid, force.ToString());
        interactor.Poke("收藏结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("关注/取关用户。程序会先查关系：已关注再关注、未关注再取关都会返回 code=-2 拦下")]
    public async Task Follow(
        [Description("目标用户的mid")] long mid,
        [Description("动作：1关注，2取关，默认1")] int act = 1,
        [Description("强制操作，默认0")] int force = 0)
    {
        string json = await RunAsync("follow", mid.ToString(), act.ToString(), force.ToString());
        interactor.Poke("关注结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("查询我对某视频/某人做过什么：是否点过赞、投过几枚币、是否已收藏、是否已关注。做任何互动前先调这个，不要靠记忆判断上次做过没有")]
    public async Task CheckDone(
        [Description("视频bvid，可留空")] string bvid = "",
        [Description("用户mid，可留空")] long mid = 0)
    {
        string json = await RunAsync("check_done", bvid, mid.ToString());
        interactor.Poke("互动状态：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("发布一条纯文字B站动态。此操作会真实发布，请谨慎")]
    public async Task PostDynamic([Description("动态正文")] string text)
    {
        string json = await RunAsync("dynamic", text);
        interactor.Poke("动态发布结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("给B站用户发一条私信。此操作会真实发送，请谨慎，内容不得包含隐私")]
    public async Task SendPrivateMsg(
        [Description("目标用户的mid")] long uid,
        [Description("私信内容")] string text)
    {
        string json = await RunAsync("pm", uid.ToString(), text);
        interactor.Poke("私信结果：" + json);
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("投递/发布一个视频到B站。此操作会真实公开投稿，务必先获得主人确认再调用。(未实机验证过，首次使用请谨慎)")]
    public async Task UploadVideo(
        [Description("本地视频文件绝对路径")] string file,
        [Description("视频标题")] string title,
        [Description("分区tid，如171=电子竞技,21=日常,138=搞笑")] int tid,
        [Description("标签，多个用逗号分隔")] string tag,
        [Description("视频简介，可选")] string desc = "")
    {
        string json = await RunAsync("upload", file, title, tid.ToString(), tag, desc);
        interactor.Poke("投稿结果：" + json);
    }

    protected override Task OnAwake()
    {
        var handler = new XmlHandler(this)
        {
            Description = "此服务可以管理B站账号：查询稿件和数据、搜索视频、读取评论弹幕、发评论/弹幕/动态/私信、点赞投币收藏关注、投稿视频。"
        };
        functionCaller.RegisterHandler(handler, DocumentMode.Implicit, cancellationToken: DestroyCancellationToken);
        return Task.CompletedTask;
    }

    protected override Task OnDestroy() => Task.CompletedTask;
}
