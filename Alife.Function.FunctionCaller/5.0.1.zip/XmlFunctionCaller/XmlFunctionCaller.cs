using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Alife.Framework;
using Alife.Foundation;
using Alife.Function.MessageFilter;
using Microsoft.Extensions.Logging;
using Microsoft.SemanticKernel.ChatCompletion;

namespace Alife.Function.FunctionCaller;

public class XmlFunctionCallerConfig
{
    [Description("触发子句分隔的字符标记。调整子句会对字幕、语音生成等流式输出的功能产生影响")]
    public List<string> Separators { get; set; } = ["，", "。", "！", "？", "…", "...", "~", "～", "—", "\n"];

    [Description("触发子句分隔的最短文本长度（字符数）")] public int MinBreakingLength { get; set; } = 23;
}

public partial class XmlFunctionCaller
{
    public static string GetDocumentTag(XmlHandler handler)
    {
        return $"[工具文档({handler.Name})]";
    }
    public static bool HasDocumentTag(string message)
    {
        return message.Contains("[工具文档(");
    }
}

[Module(
    "Xml函数调用器",
    "提供一种Xml函数调用框架，可以将注册其中的函数，暴露给AI，并指导其用Xml标签调用。",
    launchOrder: -10000, //在活动开始之前，将收集到的函数调用信息注入
    defaultCategory: "Alife 官方/功能底座")]
public partial class XmlFunctionCaller(
    ILogger<XmlFunctionCaller> logger,
    Interactor<XmlFunctionCaller> interactor,
    IMessageFilterService messageFilterService,
    ILanguageModel languageModel) :
    ChatBehaviour,
    IConfigurable<XmlFunctionCallerConfig>
{
    public event Func<Task>? ChatCalledAsync;
    public XmlFunctionCallerConfig Configuration { get; set; } = null!;
    public bool IsIdle => executor.IsFeeding;

    /// <summary>
    /// 当前系统中的函数调用注册信息。
    /// XmlHandlerTable支持你禁用其中的部分函数，从而实现拦截或手动调用的需求
    /// </summary>
    public XmlHandlerTable HandlerTable => handlerTable;

    public void RegisterHandler(XmlHandler handler, DocumentMode documentMode = DocumentMode.Explicit, CancellationToken cancellationToken = default)
    {
        handlerTable.Register(handler);
        switch (documentMode)
        {
            case DocumentMode.None:
                break;
            case DocumentMode.Implicit:
                if (handler.Name == null)
                    throw new Exception("不支持没有名称的隐式 XmlHandler");
                implicitHandlers.Add(handler);
                AddImplicitTrigger(handler);
                break;
            case DocumentMode.Explicit:
                explicitHandlers.Add(handler);
                break;
            default:
                throw new ArgumentOutOfRangeException(nameof(documentMode), documentMode, null);
        }

        if (cancellationToken != CancellationToken.None)
            cancellationToken.Register(() => UnregisterHandler(handler));

        UpdatePrompt();
    }
    public void RegisterHandlerWithoutDocument(XmlHandler handler, CancellationToken cancellationToken = default)
    {
        RegisterHandler(handler, DocumentMode.None, cancellationToken);
    }
    public void RegisterHandler(object handler, CancellationToken cancellationToken = default)
    {
        RegisterHandler(new XmlHandler(handler), cancellationToken: cancellationToken);
    }
    public void UnregisterHandler(XmlHandler handler)
    {
        handlerTable.Unregister(handler);
        explicitHandlers.Remove(handler);
        implicitHandlers.Remove(handler);

        UpdatePrompt();
    }
    /// <summary>
    /// 标记指定的xml标签内容均为生文本，不要参与xml解析，这意味着ai不需要考虑这些xml标签内容的通配问题。
    /// xml函数中被标记为[XmlForm]的参数会自动注册为plainArea
    /// </summary>
    /// <param name="plainAreas"></param>
    public void AddPlainAreas(params IEnumerable<string> plainAreas)
    {
        foreach (var plainArea in plainAreas)
            this.plainAreas.Add(plainArea);
    }

    readonly XmlHandlerTable handlerTable = new();
    readonly List<XmlHandler> explicitHandlers = new();
    readonly List<XmlHandler> implicitHandlers = new();
    readonly HashSet<string> plainAreas = new();
    XmlStreamParser parser = null!;
    XmlStreamExecutor executor = null!;
    OccupationMarker? chatOccupationMarker;
    //自动思考功能
    OccupationMarker? thinkingOccupationMarker;
    readonly List<string> thinkingReasons = new();

    protected override Task OnAwake()
    {
        messageFilterService.AddMessageReplyGuidance(() => "(注意遵守【对话输出规范】和【对话输出示例】)", DestroyCancellationToken);

        UpdatePrompt(); //提前注入一个提示词块

        return Task.CompletedTask;
    }
    protected override Task OnStart()
    {
        //统计XmlForm参数以便注册为纯文本区域
        IEnumerable<XmlParameter> parameters = handlerTable.GetAllHandlers()
            .SelectMany(handler => handler.Functions
                .SelectMany(function => function.Parameters));
        AddPlainAreas(parameters.Where(parameter => parameter.IsXmlForm)
            .Select(parameter => parameter.Name));

        //创建xml解析执行器等
        parser = new XmlStreamParser(plainAreas);
        executor = new XmlStreamExecutor(
            parser,
            handlerTable,
            Configuration.Separators.ToArray(),
            minBreakingLength: Configuration.MinBreakingLength
        );
        parser.Error += OnError;
        executor.Error += OnError;
        executor.Handling += OnHandling;
        executor.Waiting += OnWaiting;

        //AI输入回调
        ChatBot.ChatSent += OnChatSent;
        ChatBot.ChatReceived += OnChatReceived;
        ChatBot.ChatFinishedAsync += OnChatFinishedAsync;

        return Task.CompletedTask;
    }
    protected override async Task OnDestroy()
    {
        ChatBot.ChatSent -= OnChatSent;
        ChatBot.ChatReceived -= OnChatReceived;
        ChatBot.ChatFinishedAsync -= OnChatFinishedAsync;

        await executor.CancelFeeding();
        await executor.DisposeAsync();
        chatOccupationMarker?.Dispose();
        thinkingOccupationMarker?.Dispose();
    }

    void OnChatSent(string obj)
    {
        chatOccupationMarker = ChatBot.ResourceOccupiedReason.Rent("函数执行");
        thinkingReasons.Clear();
        executor.StartFeeding();
    }
    void OnChatReceived(string obj)
    {
        executor.Feed(obj);
    }
    async Task OnChatFinishedAsync(ChatContext chatContext)
    {
        //等待函数执行完成
        {
            try
            {
                await executor.EndFeeding().WaitAsync(chatContext.CancellationToken);
            }
            catch (OperationCanceledException)
            {
                await executor.CancelFeeding(); //对话被打断，取消执行
            }

            ChatBot.ResourceOccupiedReason.Return(chatOccupationMarker!);

            if (ChatCalledAsync != null)
            {
                try
                {
                    await Task.WhenAll(ChatCalledAsync.GetInvocationList()
                        .Cast<Func<Task>>()
                        .Select(func => func()));
                }
                catch (Exception e)
                {
                    AlifeLog.LogError(e);
                }
            }
        }

        if (ChatBot.ChatHistory
            .Where(content => content.Role == AuthorRole.User)
            .Any(content => content.Content != null && HasDocumentTag(content.Content)))
            thinkingReasons.Add("隐式功能激活中");

        //使用自动思考功能
        if (thinkingReasons.Count != 0)
        {
            if (thinkingOccupationMarker == null)
                thinkingOccupationMarker = languageModel.GetThinkingRequester().Rent(string.Join(" | ", thinkingReasons));
            else
                thinkingOccupationMarker.Reason = string.Join(" | ", thinkingReasons);
        }
        else if (thinkingOccupationMarker != null)
        {
            languageModel.GetThinkingRequester().Return(thinkingOccupationMarker);
            thinkingOccupationMarker = null;
        }
    }

    void OnHandling(string name, XmlContext context)
    {
        if (context.CallMode != CallMode.Opening && context.CallMode != CallMode.OneShot)
            return;

        //实现当ai调用隐射函数时自动注入对应的隐式文档
        IReadOnlyList<XmlHandler>? handlers = handlerTable.GetHandlersOfFunction(name);
        if (handlers != null) //寻找当前函数的调用处理器
        {
            foreach (XmlHandler handler in handlers)
            {
                if (implicitHandlers.Contains(handler))
                {
                    string documentTag = GetDocumentTag(handler);
                    bool hasDocumentTag = ChatBot.ChatHistory
                        .Where(content => content.Role == AuthorRole.User)
                        .Any(content => content.Content?.Contains(documentTag) ?? false);

                    if (hasDocumentTag == false)
                    {
                        interactor.Poke(GetExplicitDocument(handler));
                        thinkingReasons.Add("重新激活隐式功能");
                    }
                }
            }
        }
    }
    void OnWaiting(string name)
    {
        chatOccupationMarker!.Reason = $"执行{name}函数";
    }
    void OnError(string tag, Exception exception)
    {
        interactor.Poke($"执行{tag}标签出错：{exception.Message}");
        logger.LogInformation(exception, $"执行{tag}标签出错");
        thinkingReasons.Add("需要处理函数异常");
    }


    string GetExplicitDocument(XmlHandler handler)
    {
        return $"""
                {GetDocumentTag(handler)}
                {handler.Description} 
                #### 提供函数
                {handler.FunctionDocument()}
                {(string.IsNullOrEmpty(handler.Explanation) ? "" : $"#### 详细说明\n```\n{handler.Explanation}\n```\n")}
                """;
    }
    string GetImplicitDocument(XmlHandler handler)
    {
        return $"""
                - <{handler.Name}/> : {handler.Description}
                """;
    }
    void AddImplicitTrigger(XmlHandler source)
    {
        XmlHandler xmlHandler = new(source.Name + "_Trigger");
        xmlHandler.Functions.Add(new XmlFunction {
            Name = source.Name,
            Invoker = (_, _) => {
                interactor.Poke(GetExplicitDocument(source));
                thinkingReasons.Add("即将使用隐式功能");
                return Task.CompletedTask;
            }
        });
        handlerTable.Register(xmlHandler);
    }

    void UpdatePrompt()
    {
        //注入函数文档
        interactor.Prompt(
            $"""
             默认情况下你仅支持输出普通文本，但由于各种插件功能的存在，使得你还拥有通过输出特定的xml标签执行功能调用的能力。

             ## 使用提示

             1. 由于xml的解释器的存在，【" | & | < | >】之类的xml符号都无法直接输出，你需要使用xml转义的方式【&quot; | &amp; | &lt; | &gt;】来输出尖括号。
             2. xml调用方式非常自由，允许你进行嵌套，或一次使用多条。嵌套的函数将按顺序执行，并列的则可能顺序或并行。调用结果会在下一论对话中返回。
             3. 由于返回值是延迟的，所以你要学会中断自己的输出来等待系统结果，并通过多轮对话解决事情（如先调用隐式文档，等到收到结果后，再选择函数）
             4. 不要使用文档中不存在的函数，不要自己编造函数的返回结果。保持对函数注意力，学会循序规划的进行调用流程。
             5. 可以使用`#parallel='true/false'`参数来控制函数是否并行执行，借此可以实现任务的多线程加速，例如将说话和做事重叠进行。
             6. 并行时还可以设置`#background='true/false'`。如果函数仅设置并行但未设置后台，则每轮交互结束时会阻塞前台来等待完成，并可能被用户打断。而放入后台则不会影响你和用户继续交互，且完成后依旧可以收到结果，很适合执行长时间的等待任务。
             7. 学会为你的行为添加注释（`<!---->`）。注释中的文字可以让未来的你看到，借此你可以引导自己的情绪变化、规划解释后续操作等。一定要养成每次操作前加注释的习惯。

             ## 【对话输出示例】

             请使用如下方式和用户对话。（注意，示例中的函数不一定存在）
             ```
             <!-- 用户最近有些气馁，我也很难受，我准备给他看我最近发现的一个有趣表情包，来给他加加油！为了展示图片，我需要使用python，并同时配上鼓励的话语-->

             <!-- python执行通常需要时间，所以我要先执行python并利用#parallel将其后台运行，从而和后续的说话函数重叠进行 -->
             <Python timeout='7' #parallel='true'>
             import os
             os.startfile('cheer.png')
             <Python>

       
             <Speak>主人你看我画的好不好看，
                <!-- 开闭标签中可以嵌套其他函数，例如穿插表情动作来实现更加生动有趣演出效果，但注意先说话再表演 -->
                今天特意给你画的噢！<Expression option="开心" />
                看你每天那么累，给你打打气。<Motion option="摆摆手"/>
             </Speak>
             ```   

             ## 当前可用功能

             {string.Join("\n", explicitHandlers.Select(GetExplicitDocument))}

             ## 隐式可用功能

             有些功能是渐进式加载的，你需要显式阅读他们文档，来学习如何使用。读取隐式服务的文档非常简单，直接输出xml来调用如下标签即可：

             {(implicitHandlers.Count == 0 ? "暂无隐式功能" : string.Join("\n", implicitHandlers.Select(GetImplicitDocument)))}

             隐式工具通常专精于特定的任务，你要根据实际情况，积极的去调用他们，因为他们可以大幅提高你的工作效率和成功率。例如需要写代码就使用文件工具，需要查资料就使用浏览器工具。

             ## 原始字符串区域

             被如下标签包括的内容可以不用转义，他们会自动保持原始格式
             {string.Join(',', plainAreas)}

             ## 【对话输出规范】

             在做任何事情时，都请务必遵从这些要求！

             1. 首先写出注释并以此规划，确定简要方案后再进行实际行动。
             2. 然后查阅资料文档，收集事实、确认函数用法，避免幻觉。
             3. 接着看清消息来源和意图，根据场合选择最搭配的工具流程。
             4. 最后调用工具不要编造结果，按需等待或重叠进行，然后以此循环。
             """
        );
    }
}