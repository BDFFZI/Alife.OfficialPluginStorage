using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Alife.Function.FunctionCaller;

public class XmlHandlerTable
{
    public IReadOnlyList<XmlHandler> GetAllHandlers()
    {
        return xmlHandlers;
    }
    public IReadOnlyList<XmlHandler>? GetHandlersOfFunction(string functionName)
    {
        return functionToHandler.GetValueOrDefault(functionName);
    }
    public bool IsParallelFunction(string functionName)
    {
        return parallelFunctions.Contains(functionName);
    }

    public void Register(XmlHandler handler)
    {
        xmlHandlers.Add(handler);
        foreach (XmlFunction xmlFunction in handler.Functions)
        {
            //注册函数
            {
                if (xmlFunctions.TryGetValue(xmlFunction.Name, out SortedSet<XmlFunction>? xmlFunctionGroup) == false)
                {
                    xmlFunctionGroup = new SortedSet<XmlFunction>();
                    xmlFunctions[xmlFunction.Name] = xmlFunctionGroup;
                }

                xmlFunctionGroup.Add(xmlFunction);
            }

            //注册函数到处理器映射
            {
                if (functionToHandler.TryGetValue(xmlFunction.Name, out List<XmlHandler>? xmlHandlerGroup) == false)
                {
                    xmlHandlerGroup = new List<XmlHandler>();
                    functionToHandler[xmlFunction.Name] = xmlHandlerGroup;
                }

                xmlHandlerGroup.Add(handler);
            }

            foreach (XmlParameter parameter in xmlFunction.Parameters)
            {
                if (parameter.IsXmlForm)
                    xmlForms.Add(parameter.Name);
            }

            if (xmlFunction.Parallel)
                parallelFunctions.Add(xmlFunction.Name);
        }
    }
    public void Unregister(XmlHandler handler)
    {
        xmlHandlers.Remove(handler);
        foreach (XmlFunction xmlFunction in handler.Functions)
        {
            if (xmlFunctions.TryGetValue(xmlFunction.Name, out SortedSet<XmlFunction>? xmlFunctionGroup))
                xmlFunctionGroup.Remove(xmlFunction);

            parallelFunctions.Remove(xmlFunction.Name);
        }
    }

    /// <summary>
    /// 取消被禁用的函数
    /// </summary>
    /// <param name="function"></param>
    public void EnableFunction(XmlFunction function)
    {
        disabledFunctions.Remove(function);
    }
    /// <summary>
    /// 被禁用的函数将被跳过执行
    /// </summary>
    /// <param name="function"></param>
    public void DisableFunction(XmlFunction function)
    {
        disabledFunctions.Add(function);
    }

    public async Task Handle(string name, XmlContext tagContext, CancellationToken cancellationToken = default)
    {
        SortedSet<XmlFunction>? xmlFunctionGroup = xmlFunctions.GetValueOrDefault(name);
        if (xmlFunctionGroup == null || xmlFunctionGroup.Count == 0)
        {
            if (xmlForms.Contains(name))
                return;
            throw new Exception($"环境中没有<{name}/>，请停止使用");
        }
        foreach (XmlFunction xmlFunction in xmlFunctionGroup)
        {
            if (disabledFunctions.Contains(xmlFunction))
                continue;

            await xmlFunction.Invoker(tagContext, cancellationToken);
        }

        // Console.WriteLine($"TagHandled {tagContext.CallMode} {name} {tagContext.Content}");
    }

    readonly List<XmlHandler> xmlHandlers = new();
    readonly Dictionary<string, SortedSet<XmlFunction>> xmlFunctions = new(StringComparer.OrdinalIgnoreCase);
    readonly Dictionary<string, List<XmlHandler>> functionToHandler = new(StringComparer.OrdinalIgnoreCase);
    readonly HashSet<XmlFunction> disabledFunctions = new();
    readonly HashSet<string> xmlForms = new(StringComparer.OrdinalIgnoreCase);
    readonly HashSet<string> parallelFunctions = new(StringComparer.OrdinalIgnoreCase);
}