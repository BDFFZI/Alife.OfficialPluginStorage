# -*- coding: utf-8 -*-
"""B站直播间弹幕/礼物监听器（匿名连接版）

用法:
    python -u bili_danmu_listener.py <room_id> [--enter] [--follow] [--like]

设计要点:
- 不加载任何登录 cookie。实测带 cookie 请求 getDanmuInfo 会返回 -352（风控），
  匿名反而正常，接收弹幕/礼物本就不需要登录。
- 每收到一个事件，向 stdout 输出一行 JSON，由 C# 父进程实时读取。
  不再写文件轮询，避免日志截断 / 偏移错位导致读不到。
- blivedm 自带断线重连，脚本保持常驻。
"""
import asyncio
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "blivedm-master"))
try:
    sys.stdout.reconfigure(encoding="utf-8", line_buffering=True)
except Exception:
    pass

import aiohttp
import blivedm
from blivedm.clients import web as blivedm_web


def emit(obj: dict):
    obj["ts"] = int(time.time())
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def parse_args():
    room = 0
    opts = set()
    for a in sys.argv[1:]:
        if a.startswith("--"):
            opts.add(a[2:])
        else:
            try:
                room = int(a)
            except ValueError:
                pass
    return room, opts


ROOM, OPTS = parse_args()
WANT_ENTER = "enter" in OPTS
WANT_FOLLOW = "follow" in OPTS
WANT_LIKE = "like" in OPTS


class Handler(blivedm.BaseHandler):
    def _on_danmaku(self, client, m):
        emit({
            "type": "danmaku", "user": m.uname, "uid": m.uid, "msg": m.msg,
            "medal": m.medal_name, "medal_level": m.medal_level, "guard": m.privilege_type,
        })

    def _on_gift(self, client, m):
        emit({
            "type": "gift", "user": m.uname, "uid": m.uid, "gift": m.gift_name,
            "num": m.num, "price": m.price, "total": m.total_coin,
            "coin": m.coin_type, "guard": m.guard_level, "blind": m.blind_gift_name,
        })

    def _on_buy_guard(self, client, m):
        emit({
            "type": "guard", "user": m.username, "uid": m.uid, "level": m.guard_level,
            "name": m.gift_name, "num": m.num, "price": m.price,
        })

    def _on_user_toast_v2(self, client, m):
        # source==2 是赠送产生的重复消息，跳过
        if getattr(m, "source", 0) == 2:
            return
        emit({
            "type": "guard", "user": m.username, "uid": m.uid, "level": m.guard_level,
            "name": m.gift_name, "num": m.num, "price": m.price,
        })

    def _on_super_chat(self, client, m):
        emit({
            "type": "superchat", "user": m.uname, "uid": m.uid,
            "price": m.price, "msg": m.message, "time": m.time,
        })

    def _on_interact_word_v2(self, client, m):
        if m.msg_type == 1 and WANT_ENTER:
            emit({"type": "enter", "user": m.username, "uid": m.uid})
        elif m.msg_type in (2, 4) and WANT_FOLLOW:
            emit({"type": "follow", "user": m.username, "uid": m.uid})
        elif m.msg_type == 6 and WANT_LIKE:
            emit({"type": "like", "user": m.username, "uid": m.uid})


async def main():
    if ROOM <= 0:
        emit({"type": "status", "state": "error", "detail": "invalid room id"})
        return

    emit({"type": "status", "state": "starting", "room": ROOM})
    jar = aiohttp.CookieJar()  # 匿名，不加载 cookie
    session = aiohttp.ClientSession(cookie_jar=jar, trust_env=False)
    try:
        client = blivedm_web.BLiveClient(room_id=ROOM, uid=0, session=session)
        client.set_handler(Handler())
        if not await client.init_room():
            emit({"type": "status", "state": "init_fail", "room": ROOM})
            return
        emit({"type": "status", "state": "connected", "room": client.room_id})
        client.start()
        while True:
            await asyncio.sleep(10)
    except Exception as e:
        emit({"type": "status", "state": "error", "detail": repr(e)})
    finally:
        await session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
