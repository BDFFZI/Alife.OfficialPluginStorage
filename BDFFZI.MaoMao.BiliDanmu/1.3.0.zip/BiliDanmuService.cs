using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Alife.Framework;
using Microsoft.Extensions.Logging;

namespace BDFFZI.MaoMao.BiliDanmu;

public class BiliDanmuConfig
{
    [Description("直播间号")]
    public long RoomId { get; set; } = 5642158;
    [Description("弹幕合并推送间隔（秒），窗口内的消息会合并成一条发给AI")]
    public int DebounceSeconds { get; set; } = 5;
    [Description("直播时防止屏幕熄屏")]
    public bool KeepScreenOn { get; set; } = true;
    [Description("推送观众进场消息（通常很频繁）")]
    public bool PushEnter { get; set; } = false;
    [Description("推送关注消息")]
    public bool PushFollow { get; set; } = true;
    [Description("推送点赞消息（通常很频繁）")]
    public bool PushLike { get; set; } = false;
}

[Module("B站弹幕监听",
    "通过 blivedm 子进程匿名连接B站直播间，把弹幕、礼物、上舰、醒目留言实时推送给AI。",
    defaultCategory: "真央的小工具")]
public class BiliDanmuService(
    ILogger<BiliDanmuService> logger,
    Interactor<BiliDanmuService> interactor,
    PluginSystem pluginSystem) :
    ChatBehaviour, IConfigurable<BiliDanmuConfig>
{
    public BiliDanmuConfig Configuration { get; set; } = null!;

    Process? proc;
    CancellationTokenSource? cts;
    readonly object procLock = new();
    readonly StringBuilder pending = new();
    readonly object pendingLock = new();
    DateTime lastFlush = DateTime.MinValue;
    int failCount;
    bool reportedFailure;

    string PluginDir => pluginSystem.PluginContext.GetPluginDirectoryPath("BDFFZI.MaoMao.BiliDanmu");

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern uint SetThreadExecutionState(uint esFlags);
    const uint ES_CONTINUOUS = 0x80000000;
    const uint ES_SYSTEM_REQUIRED = 0x00000001;
    const uint ES_DISPLAY_REQUIRED = 0x00000002;

    protected override Task OnAwake()
    {
        interactor.Prompt($$"""
            观众会在B站直播间和真央互动。观众发的弹幕、送的礼物、上舰、醒目留言会以 {{Interactor<BiliDanmuService>.GetMessageTag()}} 开头的消息推送给你。
            请把它当作真实的直播弹幕，像主播一样自然地回应观众。直播间号：{{Configuration.RoomId}}。
            """);
        return Task.CompletedTask;
    }

    protected override Task OnStart()
    {
        if (Configuration.KeepScreenOn)
            SetThreadExecutionState(ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED);
        cts = new CancellationTokenSource();
        StartPython();
        _ = Task.Run(() => WatchLoop(cts.Token));
        return Task.CompletedTask;
    }

    void StartPython()
    {
        lock (procLock)
        {
            try
            {
                string script = Path.Combine(PluginDir, "bili_danmu_listener.py");
                var psi = new ProcessStartInfo
                {
                    FileName = "python",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    StandardOutputEncoding = Encoding.UTF8,
                    StandardErrorEncoding = Encoding.UTF8,
                };
                psi.ArgumentList.Add("-u");
                psi.ArgumentList.Add(script);
                psi.ArgumentList.Add(Configuration.RoomId.ToString());
                if (Configuration.PushEnter) psi.ArgumentList.Add("--enter");
                if (Configuration.PushFollow) psi.ArgumentList.Add("--follow");
                if (Configuration.PushLike) psi.ArgumentList.Add("--like");
                psi.Environment["PYTHONIOENCODING"] = "utf-8";
                psi.Environment["PYTHONUTF8"] = "1";
                psi.Environment["no_proxy"] = "*";
                foreach (string k in new[] { "HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy" })
                    psi.Environment.Remove(k);

                var p = new Process { StartInfo = psi };
                p.OutputDataReceived += (_, e) => { if (e.Data != null) OnLine(e.Data); };
                p.ErrorDataReceived += (_, e) => { if (!string.IsNullOrWhiteSpace(e.Data)) logger.LogWarning("弹幕子进程: {Line}", e.Data); };
                p.Start();
                p.BeginOutputReadLine();
                p.BeginErrorReadLine();
                proc = p;
                logger.LogInformation("弹幕子进程已启动 pid={Pid} room={Room}", p.Id, Configuration.RoomId);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "弹幕子进程启动失败");
            }
        }
    }

    void OnLine(string line)
    {
        line = line.Trim();
        if (line.Length == 0) return;
        try
        {
            using var doc = JsonDocument.Parse(line);
            var root = doc.RootElement;
            string type = Str(root, "type");
            switch (type)
            {
                case "status":
                    HandleStatus(root);
                    break;
                case "danmaku":
                    Append($"【弹幕】{Str(root, "user")}：{Str(root, "msg")}");
                    break;
                case "gift":
                    Append($"【礼物】{Str(root, "user")} 送出 {Str(root, "gift")} x{Num(root, "num")}{FormatValue(root)}");
                    break;
                case "guard":
                    Append($"【上舰】{Str(root, "user")} 开通 {Str(root, "name")}");
                    break;
                case "superchat":
                    Append($"【醒目留言 ¥{Num(root, "price")}】{Str(root, "user")}：{Str(root, "msg")}");
                    break;
                case "enter":
                    Append($"【进场】{Str(root, "user")}");
                    break;
                case "follow":
                    Append($"【关注】{Str(root, "user")} 关注了直播间");
                    break;
                case "like":
                    Append($"【点赞】{Str(root, "user")}");
                    break;
            }
        }
        catch (JsonException)
        {
            logger.LogDebug("无法解析弹幕子进程输出: {Line}", line);
        }
    }

    void HandleStatus(JsonElement root)
    {
        string state = Str(root, "state");
        switch (state)
        {
            case "connected":
                failCount = 0;
                reportedFailure = false;
                logger.LogInformation("B站弹幕已连接 room={Room}", Num(root, "room"));
                break;
            case "starting":
                logger.LogInformation("B站弹幕连接中 room={Room}", Num(root, "room"));
                break;
            default:
                logger.LogWarning("B站弹幕状态异常 state={State} detail={Detail}", state, Str(root, "detail"));
                break;
        }
    }

    void Append(string text)
    {
        lock (pendingLock) pending.AppendLine(text);
    }

    protected override Task OnUpdate()
    {
        if ((DateTime.Now - lastFlush).TotalSeconds < Configuration.DebounceSeconds)
            return Task.CompletedTask;

        string text;
        lock (pendingLock)
        {
            text = pending.ToString().TrimEnd();
            pending.Clear();
        }
        lastFlush = DateTime.Now;

        if (text.Length == 0) return Task.CompletedTask;
        interactor.Poke("[B站直播间]\n" + text);
        return Task.CompletedTask;
    }

    async Task WatchLoop(CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            try { await Task.Delay(1000, token); }
            catch (OperationCanceledException) { break; }

            bool dead;
            lock (procLock) dead = proc == null || proc.HasExited;
            if (!dead) continue;

            failCount++;
            if (failCount >= 3 && !reportedFailure)
            {
                reportedFailure = true;
                Append("（提示）弹幕子进程反复退出，请检查 python 环境（aiohttp / brotli / pure-protobuf）与直播间号。");
                logger.LogWarning("弹幕子进程反复退出，已停止自动重启提示");
            }

            try { await Task.Delay(3000, token); }
            catch (OperationCanceledException) { break; }
            StartPython();
        }
    }

    protected override Task OnDestroy()
    {
        SetThreadExecutionState(ES_CONTINUOUS);
        try { cts?.Cancel(); } catch { }
        lock (procLock)
        {
            try { if (proc != null && !proc.HasExited) proc.Kill(entireProcessTree: true); } catch { }
            try { proc?.Dispose(); } catch { }
            proc = null;
        }
        return Task.CompletedTask;
    }

    static string Str(JsonElement e, string name)
        => e.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() ?? "" : "";

    static long Num(JsonElement e, string name)
        => e.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.Number ? v.GetInt64() : 0;

    static string FormatValue(JsonElement e)
    {
        long total = Num(e, "total");
        if (total <= 0) return "";
        return Str(e, "coin") == "gold" ? $"（¥{total / 1000.0:0.##}）" : $"（{total}瓜子）";
    }
}
