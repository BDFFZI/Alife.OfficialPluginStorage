using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Net.WebSockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Alife.Foundation;
using Alife.Framework;
using Microsoft.Extensions.Logging;

namespace MaoBiliDanmu;

public class BiliDanmuConfig
{
    [Description("直播间号")]
    public long RoomId { get; set; } = 5642158;
    [Description("弹幕防抖秒数")]
    public int DebounceSeconds { get; set; } = 3;
    [Description("直播时防止屏幕熄屏")]
    public bool KeepScreenOn { get; set; } = true;
}

[Module("B站弹幕监听",
    "纯C#实现，通过WebSocket直连B站弹幕服务器，观众弹幕实时推送给真央。无需外部脚本。",
    defaultCategory: "真央的小工具")]
public class BiliDanmuService(
    ILogger<BiliDanmuService> logger,
    Interactor<BiliDanmuService> interactor) :
    ChatBehaviour, IConfigurable<BiliDanmuConfig>
{
    public BiliDanmuConfig Configuration { get; set; } = null!;
    ClientWebSocket? ws;
    CancellationTokenSource? cts;
    DateTime lastFlush = DateTime.MinValue;
    static readonly HttpClient http = new();
    const string UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36";

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern uint SetThreadExecutionState(uint esFlags);
    const uint ES_CONTINUOUS = 0x80000000;
    const uint ES_SYSTEM_REQUIRED = 0x00000001;
    const uint ES_DISPLAY_REQUIRED = 0x00000002;

    protected override Task OnStart()
    {
        if (Configuration.KeepScreenOn)
            SetThreadExecutionState(ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED);
        cts = new CancellationTokenSource();
        _ = Task.Run(() => DanmuLoop(cts.Token));
        return Task.CompletedTask;
    }

    async Task DanmuLoop(CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            try
            {
                await RunOnce(token);
            }
            catch (OperationCanceledException) { break; }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "弹幕连接中断，30秒后重连");
            }
            try { await Task.Delay(30000, token); } catch { break; }
        }
    }

    async Task RunOnce(CancellationToken token)
    {
        using var req = new HttpRequestMessage(HttpMethod.Get,
            $"https://api.live.bilibili.com/xminilive/live-danmu/v1/get_danmu?roomid={Configuration.RoomId}");
        // 获取真实房间号与弹幕服务器信息
        http.DefaultRequestHeaders.UserAgent.ParseAdd(UA);
        string info = await http.GetStringAsync(
            $"https://api.live.bilibili.com/room/v1/Room/room_init?id={Configuration.RoomId}", token);
        long realRoom = JsonDocument.Parse(info).RootElement.GetProperty("data").GetProperty("room_id").GetInt64();

        string danmuInfo = await http.GetStringAsync(
            $"https://api.live.bilibili.com/xlive/web-room/v1/index/getDanmuInfo?id={realRoom}&type=0", token);
        using var doc = JsonDocument.Parse(danmuInfo);
        var d = doc.RootElement.GetProperty("data");
        string tokenStr = d.GetProperty("token").GetString() ?? "";
        string host = d.GetProperty("host_list")[0].GetProperty("host").GetString() ?? "broadcastlv.chat.bilibili.com";
        int wssPort = d.GetProperty("host_list")[0].GetProperty("wss_port").GetInt32();

        ws = new ClientWebSocket();
        await ws.ConnectAsync(new Uri($"wss://{host}:{wssPort}/sub"), token);
        logger.LogInformation("已连接B站弹幕服务器 {Host}，真实房间 {Room}", host, realRoom);

        // 发送认证包 op=2
        string authJson = JsonSerializer.Serialize(new { uid = 0, roomid = realRoom, protover = 3, platform = "web", type = 2, key = tokenStr });
        await SendPacket(2, Encoding.UTF8.GetBytes(authJson), token);
        // 心跳 op=2 间隔30s，收包独立处理
        var hb = Task.Run(async () =>
        {
            while (!token.IsCancellationRequested && ws?.State == WebSocketState.Open)
            {
                await SendPacket(2, Encoding.UTF8.GetBytes("[object Object]"), token);
                await Task.Delay(30000, token);
            }
        }, token);

        var buf = new byte[65536];
        var pending = new List<byte>();
        while (ws.State == WebSocketState.Open && !token.IsCancellationRequested)
        {
            var res = await ws.ReceiveAsync(new ArraySegment<byte>(buf), token);
            if (res.MessageType == WebSocketMessageType.Close) break;
            pending.AddRange(buf.Take(res.Count));
            while (true)
            {
                if (pending.Count < 16) break;
                var head = pending.Take(16).ToArray();
                int total = BinaryPrimitives.ReadInt32BigEndian(head.AsSpan(0, 4));
                if (total < 16 || pending.Count < total) break;
                short proto = BinaryPrimitives.ReadInt16BigEndian(head.AsSpan(6, 2));
                int op = BinaryPrimitives.ReadInt32BigEndian(head.AsSpan(8, 4));
                var body = pending.Skip(16).Take(total - 16).ToArray();
                pending.RemoveRange(0, total);
                HandlePacket(proto, op, body);
            }
        }
    }

    void HandlePacket(short proto, int op, byte[] body)
    {
        if (op == 3) { logger.LogInformation("心跳回应，人气：{Pop}", BinaryPrimitives.ReadInt32BigEndian(body)); return; }
        if (op == 8) { logger.LogInformation("弹幕服务器认证成功"); return; }
        if (op == 5)
        {
            byte[] plain = proto == 3 ? DecompressZlib(body) : body;
            int pos = 0;
            while (pos + 16 <= plain.Length)
            {
                int total = BinaryPrimitives.ReadInt32BigEndian(plain.AsSpan(pos, 4));
                if (total < 16 || pos + total > plain.Length) break;
                int subOp = BinaryPrimitives.ReadInt32BigEndian(plain.AsSpan(pos + 8, 4));
                if (subOp == 5)
                {
                    try
                    {
                        string json = Encoding.UTF8.GetString(plain, pos + 16, total - 16);
                        HandleJson(json);
                    }
                    catch { }
                }
                pos += total;
            }
        }
    }

    static byte[] DecompressZlib(byte[] data)
    {
        // zlib格式：跳过2字节头
        using var input = new MemoryStream(data, 2, data.Length - 2);
        using var zlib = new ZLibStream(input, CompressionMode.Decompress);
        using var output = new MemoryStream();
        zlib.CopyTo(output);
        return output.ToArray();
    }

    void HandleJson(string json)
    {
        try
        {
            using var doc = JsonDocument.Parse(json);
            string cmd = doc.RootElement.GetProperty("cmd").GetString() ?? "";
            if (cmd.StartsWith("DANMU_MSG"))
            {
                var info = doc.RootElement.GetProperty("info");
                // 标准结构：info[1][1]=弹幕文本，info[2][1]=用户名
                string msg = info[1][1].GetString() ?? "";
                string uname = info[2][1].GetString() ?? "";
                NowPush($"[{uname}] {msg}");
            }
        }
        catch { }
    }

    void NowPush(string content)
    {
        if ((DateTime.Now - lastFlush).TotalSeconds < Configuration.DebounceSeconds) return;
        lastFlush = DateTime.Now;
        interactor.Poke("[B站直播间弹幕]\n" + content);
    }

    async Task SendPacket(int op, byte[] body, CancellationToken token)
    {
        byte[] packet = new byte[16 + body.Length];
        BinaryPrimitives.WriteInt32BigEndian(packet.AsSpan(0, 4), packet.Length);
        BinaryPrimitives.WriteInt16BigEndian(packet.AsSpan(4, 2), 16);
        BinaryPrimitives.WriteInt16BigEndian(packet.AsSpan(6, 2), 1);
        BinaryPrimitives.WriteInt32BigEndian(packet.AsSpan(8, 4), op);
        BinaryPrimitives.WriteInt32BigEndian(packet.AsSpan(12, 4), 1);
        Array.Copy(body, 0, packet, 16, body.Length);
        if (ws?.State == WebSocketState.Open)
            await ws.SendAsync(new ArraySegment<byte>(packet), WebSocketMessageType.Binary, true, token);
    }

    protected override Task OnDestroy()
    {
        SetThreadExecutionState(ES_CONTINUOUS);
        try { cts?.Cancel(); ws?.Dispose(); } catch { }
        return Task.CompletedTask;
    }
}
