using System.ComponentModel;
using System.Threading;
using System.Threading.Tasks;
using Alife.Framework;
using Alife.Function.FunctionCaller;

namespace Alife.Function.Python;

[Module("脚本执行（已弃用）",
    "该插件已弃用，请改用 Alife.Function.Execution。",
    defaultCategory: "Alife 官方/实用工具")]
public class PythonService : ChatBehaviour
{
    [Description("执行python脚本（已弃用）")]
    public Task Python(XmlExecutorContext context, string script,
        [Description("预估运行时间（单位秒）")] int timeout, CancellationToken cancellationToken)
    {
        return Task.CompletedTask;
    }

    [Description("下载文件（已弃用）")]
    public Task DownloadFile(string url, string path)
    {
        return Task.CompletedTask;
    }

    public static Task<string> Python(string path, int timeout = 30, CancellationToken cancellationToken = default)
    {
        return Task.FromResult(string.Empty);
    }
}
