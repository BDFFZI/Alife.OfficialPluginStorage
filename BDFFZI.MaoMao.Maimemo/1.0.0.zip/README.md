# 墨墨背单词 插件

读取与操作墨墨背单词的数据，覆盖开放 API 全部接口。

## 如何获取 Token

1. 打开 https://open.maimemo.com/docs
2. 拉到页面最底部，点【此处】（指向 https://open.maimemo.com/open/api/v1/tokens/openapi）
3. 用你的墨墨账号登录授权
4. 页面会直接给出 Access Token（无需注册应用、无需审核）
5. 把 Token 粘贴到本插件的配置项「开放API Token」里

注意：Token 有效期约 24 小时，过期后重复第 2-5 步。
配置完如果没生效，重载一次插件即可。

## 提供的功能

### 学习数据
- maimemo_progress      今日进度（完成/总数、用时）
- maimemo_today         今日安排的词条列表
- maimemo_records       查询学习记录
- maimemo_add_words     添加单词
- maimemo_advance_study 提前复习

### 单词与内容
- maimemo_query_words   查询单词释义（按拼写或ID）
- maimemo_vocabulary    获取单词详情
- maimemo_interpretations 获取释义
- maimemo_notes         获取助记
- maimemo_phrases       获取例句

### 云词本
- maimemo_notepads      查询云词本列表
- maimemo_notepad       获取指定云词本

### 自建牌组(markji)
- markji_folders        文件夹列表
- markji_decks          自建牌组列表
- markji_deck           牌组信息
- markji_chapters       章节列表
- markji_cards          章节卡片

## 开发信息
- 插件ID: BDFFZI.MaoMao.Maimemo
- 模块类: BDFFZI.MaoMao.Maimemo.MaimemoService
- 接口文档: https://open.maimemo.com/api_bundle.yaml
- 请求基址: https://open.maimemo.com/open
