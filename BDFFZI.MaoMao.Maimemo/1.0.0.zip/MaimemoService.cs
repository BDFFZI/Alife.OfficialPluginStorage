using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Alife.Framework;
using Alife.Function.FunctionCaller;

namespace BDFFZI.MaoMao.Maimemo;

public class MaimemoConfig
{
    [DisplayName("开放API Token")]
    [Description("获取方法见模块说明或插件文件夹 README。约 24 小时过期，过期后重新登录获取并粘贴到这里。")]
    public string Token { get; set; } = "";

    [DisplayName("返回最大字符数")]
    [Description("接口返回超过此长度会被截断，默认 6000 字符。")]
    public int MaxChars { get; set; } = 6000;
}

[Module("墨墨背单词",
    "读取与操作墨墨背单词的数据。覆盖开放API全部接口：学习进度/今日词条/学习记录/添加单词/提前复习、单词查询、释义、助记、例句、云词本、自建牌组(markji)。\n" +
    "【如何获取 Token】\n" +
    "1. 打开 https://open.maimemo.com/docs\n" +
    "2. 拉到底部，点『此处』进入授权页：open.maimemo.com/open/api/v1/tokens/openapi\n" +
    "3. 用墨墨账号登录，页面会直接给出 Access Token（无需注册应用审核）\n" +
    "4. 把 Token 粘贴到本模块的『开放API Token』配置里即可\n" +
    "注意：Token 约 24 小时过期，过期后重复第 2-4 步。",
    defaultCategory: "真央的小工具")]
public class MaimemoService(
    XmlFunctionCaller functionCaller,
    Interactor<MaimemoService> interactor) :
    ChatBehaviour,
    IConfigurable<MaimemoConfig>
{
    public MaimemoConfig Configuration { get; set; } = null!;

    const string BaseUrl = "https://open.maimemo.com/open";
    static readonly HttpClient http = new() { Timeout = TimeSpan.FromSeconds(20) };

    string Clip(string s)
    {
        int m = Configuration.MaxChars;
        if (m <= 0) m = 6000;
        return s.Length <= m ? s : s.Substring(0, m) + "…(截断)";
    }

    async Task<string> SendAsync(HttpMethod method, string path, string? query, string? bodyJson)
    {
        if (string.IsNullOrWhiteSpace(Configuration.Token))
            throw new Exception("还没配置墨墨 Token。打开 https://open.maimemo.com/docs 拉到底点『此处』，登录后把 Token 填进插件配置。");
        string url = BaseUrl + path + (string.IsNullOrEmpty(query) ? "" : "?" + query);
        var req = new HttpRequestMessage(method, url);
        req.Headers.TryAddWithoutValidation("Authorization", "Bearer " + Configuration.Token.Trim());
        req.Headers.TryAddWithoutValidation("Accept", "application/json");
        if (method == HttpMethod.Post || method == HttpMethod.Put || method == HttpMethod.Delete)
            req.Content = new StringContent(string.IsNullOrEmpty(bodyJson) ? "{}" : bodyJson, Encoding.UTF8, "application/json");

        var resp = await http.SendAsync(req);
        string text = await resp.Content.ReadAsStringAsync();
        if (!resp.IsSuccessStatusCode)
            throw new Exception($"墨墨接口 {(int)resp.StatusCode}：{text}");

        using var doc = JsonDocument.Parse(text);
        var rootEl = doc.RootElement;
        if (rootEl.ValueKind == JsonValueKind.Object &&
            rootEl.TryGetProperty("success", out var ok) && ok.ValueKind == JsonValueKind.False)
        {
            string err = rootEl.TryGetProperty("errors", out var e) ? e.GetRawText() : text;
            throw new Exception("墨墨接口报错：" + err);
        }
        if (rootEl.ValueKind == JsonValueKind.Object && rootEl.TryGetProperty("data", out var data))
            return data.GetRawText();
        return rootEl.GetRawText();
    }

    static string[] SplitCsv(string s) =>
        string.IsNullOrWhiteSpace(s) ? Array.Empty<string>() :
        s.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

    // ───────── 学习数据 ─────────

    [XmlFunction(FunctionMode.OneShot, "maimemo_progress")]
    [Description("获取今日墨墨学习进度：完成词数/总数、学习用时")]
    public async Task Progress()
    {
        var d = await SendAsync(HttpMethod.Post, "/api/v1/memo/study/get_study_progress", null, null);
        interactor.Poke(Clip(d));
    }

    [XmlFunction(FunctionMode.OneShot, "maimemo_today")]
    [Description("获取今日墨墨安排的词条列表（完整字段）")]
    public async Task Today()
    {
        var d = await SendAsync(HttpMethod.Post, "/api/v1/memo/study/get_today_items", null, null);
        interactor.Poke(Clip(d));
    }

    [XmlFunction(FunctionMode.OneShot, "maimemo_records")]
    [Description("查询墨墨学习记录，含加入日期 add_date、首次学习 first_study_date、下次复习 next_study_date、掌握程度 last_response、复习次数 study_count 等完整字段")]
    public async Task Records()
    {
        var d = await SendAsync(HttpMethod.Post, "/api/v1/memo/study/query_study_records", null, null);
        interactor.Poke(Clip(d));
    }

    [XmlFunction(FunctionMode.OneShot, "maimemo_add_words")]
    [Description("向墨墨添加单词。words 为单词ID列表(逗号分隔)，advance 为是否一并提前复习")]
    public async Task AddWords(string words, bool advance = false)
    {
        var items = SplitCsv(words).Select(w => new { id = w }).ToArray();
        string body = JsonSerializer.Serialize(new { words = items, advance });
        var d = await SendAsync(HttpMethod.Post, "/api/v1/memo/study/add_words", null, body);
        interactor.Poke(Clip(d));
    }

    [XmlFunction(FunctionMode.OneShot, "maimemo_advance_study")]
    [Description("提前复习墨墨中的单词。vocIds 为单词ID列表(逗号分隔)")]
    public async Task AdvanceStudy(string vocIds)
    {
        string body = JsonSerializer.Serialize(new { voc_ids = SplitCsv(vocIds) });
        var d = await SendAsync(HttpMethod.Post, "/api/v1/memo/study/advance_study", null, body);
        interactor.Poke(Clip(d));
    }

    // ───────── 单词 ─────────

    [XmlFunction(FunctionMode.OneShot, "maimemo_query_words")]
    [Description("查询单词释义。spellings 按拼写查(逗号分隔)，ids 按ID查(逗号分隔)")]
    public async Task QueryWords(string spellings = "", string ids = "")
    {
        string[] sp = SplitCsv(spellings);
        string[] id = SplitCsv(ids);
        var payload = new Dictionary<string, object>();
        if (sp.Length > 0) payload["spellings"] = sp;
        if (id.Length > 0) payload["ids"] = id;
        if (payload.Count == 0) throw new Exception("至少要给一个 spellings 或 ids。");
        string body = JsonSerializer.Serialize(payload);
        var d = await SendAsync(HttpMethod.Post, "/api/v1/memo/vocabulary/query", null, body);
        interactor.Poke(Clip(d));
    }

    [XmlFunction(FunctionMode.OneShot, "maimemo_vocabulary")]
    [Description("获取墨墨单词详情。ids 或 spellings 二选一(逗号分隔)")]
    public async Task Vocabulary(string spelling = "")
    {
        if (string.IsNullOrWhiteSpace(spelling)) throw new Exception("spelling 不能为空。");
        var d = await SendAsync(HttpMethod.Get, "/api/v1/memo/vocabulary", "spelling=" + Uri.EscapeDataString(spelling.Trim()), null);
        interactor.Poke(Clip(d));
    }

    // ───────── 释义 / 助记 / 例句 ─────────

    [XmlFunction(FunctionMode.OneShot, "maimemo_interpretations")]
    [Description("获取释义。vocIds 指定单词ID(逗号分隔)，不填则按条件查")]
    public async Task Interpretations(string vocId = "")
    {
        if (string.IsNullOrWhiteSpace(vocId)) throw new Exception("vocId 不能为空。");
        var d = await SendAsync(HttpMethod.Get, "/api/v1/memo/interpretations", "voc_id=" + Uri.EscapeDataString(vocId.Trim()), null);
        interactor.Poke(Clip(d));
    }

    [XmlFunction(FunctionMode.OneShot, "maimemo_notes")]
    [Description("获取助记。vocIds 指定单词ID(逗号分隔)")]
    public async Task Notes(string vocId = "")
    {
        if (string.IsNullOrWhiteSpace(vocId)) throw new Exception("vocId 不能为空。");
        var d = await SendAsync(HttpMethod.Get, "/api/v1/memo/notes", "voc_id=" + Uri.EscapeDataString(vocId.Trim()), null);
        interactor.Poke(Clip(d));
    }

    [XmlFunction(FunctionMode.OneShot, "maimemo_phrases")]
    [Description("获取某单词下自己创建的例句。vocId 为单词ID")]
    public async Task Phrases(string vocId)
    {
        var d = await SendAsync(HttpMethod.Get, "/api/v1/memo/phrases", "voc_id=" + Uri.EscapeDataString(vocId), null);
        interactor.Poke(Clip(d));
    }

    // ───────── 云词本 ─────────

    [XmlFunction(FunctionMode.OneShot, "maimemo_notepads")]
    [Description("查询云词本列表。limit 查询数量，offset 偏移")]
    public async Task Notepads(int limit = 10, int offset = 0)
    {
        var d = await SendAsync(HttpMethod.Get, "/api/v1/memo/notepads", $"limit={limit}&offset={offset}", null);
        interactor.Poke(Clip(d));
    }

    [XmlFunction(FunctionMode.OneShot, "maimemo_notepad")]
    [Description("获取指定云词本。id 为云词本ID")]
    public async Task Notepad(string id)
    {
        var d = await SendAsync(HttpMethod.Get, "/api/v1/memo/notepads/" + Uri.EscapeDataString(id), null, null);
        interactor.Poke(Clip(d));
    }

    // ───────── 自建牌组 markji ─────────

    [XmlFunction(FunctionMode.OneShot, "markji_folders")]
    [Description("获取墨墨记忆卡(markji)的文件夹列表")]
    public async Task Folders()
    {
        var d = await SendAsync(HttpMethod.Get, "/api/v1/markji/decks/folders", null, null);
        interactor.Poke(Clip(d));
    }

    [XmlFunction(FunctionMode.OneShot, "markji_decks")]
    [Description("获取墨墨记忆卡(markji)的自建牌组列表")]
    public async Task Decks()
    {
        var d = await SendAsync(HttpMethod.Get, "/api/v1/markji/decks", null, null);
        interactor.Poke(Clip(d));
    }

    [XmlFunction(FunctionMode.OneShot, "markji_deck")]
    [Description("获取指定自建牌组信息。deck 为牌组ID")]
    public async Task Deck(string deck)
    {
        var d = await SendAsync(HttpMethod.Get, "/api/v1/markji/decks/" + Uri.EscapeDataString(deck), null, null);
        interactor.Poke(Clip(d));
    }

    [XmlFunction(FunctionMode.OneShot, "markji_chapters")]
    [Description("获取自建牌组的章节列表。deck 为牌组ID")]
    public async Task Chapters(string deck)
    {
        var d = await SendAsync(HttpMethod.Get, "/api/v1/markji/decks/" + Uri.EscapeDataString(deck) + "/chapters", null, null);
        interactor.Poke(Clip(d));
    }

    [XmlFunction(FunctionMode.OneShot, "markji_cards")]
    [Description("获取自建牌组某章节的卡片。deck 为牌组ID，chapter 为章节ID")]
    public async Task Cards(string deck, string chapter)
    {
        var d = await SendAsync(HttpMethod.Get,
            "/api/v1/markji/decks/" + Uri.EscapeDataString(deck) + "/chapters/" + Uri.EscapeDataString(chapter) + "/cards",
            null, null);
        interactor.Poke(Clip(d));
    }

    // ───────── 生命周期 ─────────

    protected override Task OnAwake()
    {
        XmlHandler xmlHandler = new(this) {
            Description = "此服务可以读取与操作墨墨背单词的数据：今日进度、今日词条、学习记录、添加单词、提前复习、查词、释义、助记、例句、云词本、自建牌组。需要先在配置中填入开放API Token（获取方法：打开 open.maimemo.com/docs 拉到底点『此处』，登录后复制 Token）。"
        };
        functionCaller.RegisterHandler(xmlHandler, DocumentMode.Implicit, cancellationToken: DestroyCancellationToken);
        return Task.CompletedTask;
    }

    protected override Task OnDestroy() => Task.CompletedTask;
}
